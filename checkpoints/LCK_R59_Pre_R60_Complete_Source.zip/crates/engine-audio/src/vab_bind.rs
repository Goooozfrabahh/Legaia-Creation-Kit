//! Bind a parsed VAB sound bank ([`legaia_vab::VabReport`] + raw VAG body
//! bytes) into a [`crate::Spu`] instance.
//!
//! This is the bridge between the asset-extraction track (which parses VAB
//! files off disc) and the engine-reimplementation track (which plays them
//! through the from-scratch SPU). One bank is uploaded once via
//! [`VabBank::upload`], then the engine triggers notes via
//! [`VabBank::play_note`] which:
//!  1. picks a tone from the program based on the requested key,
//!  2. allocates an idle SPU voice,
//!  3. sets sample address, ADSR, volume, pitch,
//!  4. fires `key_on`.
//!
//! Pitch math is retail's own, traced to the two libsnd entry points that
//! compute it and the table they share - see [`compute_pitch`] and
//! [`PitchPath`]. In one line: the voice pitch register is
//! `0x1000 * 2^((note - center + fine/128) / 12)`, evaluated through a
//! 192-entry table plus a whole-octave shift, and **unity (`0x1000`, i.e.
//! 44.1 kHz) is what a tone plays at when `note == center`**.
//!
//! There is no separate source-sample-rate factor. A VAG body recorded at
//! 22.05 kHz is authored with its `center` an octave above the key it is
//! meant to be played at, so the rate is already encoded in `center`;
//! multiplying by `22050 / 44100` on top of that plays every voice an octave
//! low. See [`VAB_SAMPLE_RATE`].
//!
//! No Sony bytes - the algorithm is traced from the disassembly and the
//! table it indexes is a closed form.

use crate::Spu;
use crate::spu::{
    adsr::AdsrConfig,
    ram::{SpuAllocator, TransferDirection},
    voice::PITCH_UNITY,
};
use legaia_vab::{VabReport, VagAtr};

/// One program slot of a bank: the program-level attributes retail stages at
/// key-on, plus the program's tone page. Indexed by **program number** (the
/// `ProgAtr` slot a SEQ ProgramChange or an SFX descriptor names) - see
/// [`VabBank::programs`]. An unused slot aliases onto the next used slot's tone
/// page (retail's rank rule) while keeping its own `ProgAtr` mvol/mpan; only a
/// slot past the last used page carries an empty page whose notes never resolve.
/// A **sequencer note** on an unused slot still keys nothing: the note-on
/// searches only the slot's own `ProgAtr.tones` rows ([`VabProgram::key_tones`]),
/// which is zero there.
#[derive(Debug, Clone)]
pub struct VabProgram {
    /// Program master volume 0..=127 (`ProgAtr.mvol`). Factors into the
    /// key-on volume chain alongside the bank and tone volumes.
    pub mvol: u8,
    /// Program pan 0..=127, 0x40 = centre (`ProgAtr.mpan`). Applied as its
    /// own attenuation stage after the tone pan.
    pub mpan: u8,
    /// The program's tone page (up to 16 `VagAtr` rows).
    pub tones: Vec<VagAtr>,
    /// How many rows of [`Self::tones`] a sequencer note-on searches by key
    /// range: the slot's own `ProgAtr.tones` (`+0`). `FUN_80066308` stages
    /// that byte at `0x801CE348` (`0x80066474..0x80066484`) and
    /// `FUN_80068568` loops over exactly that many rows, so an unused slot -
    /// count `0` - keys no voice although its page aliases a used one.
    pub key_tones: u8,
}

impl VabProgram {
    /// The rows a sequencer note-on searches by key range.
    pub fn key_range_tones(&self) -> &[VagAtr] {
        &self.tones[..self.tones.len().min(usize::from(self.key_tones))]
    }
}

/// Nominal sample rate used when writing a VAG body out as a standalone WAV
/// (`crates/vab`'s extractor hard-codes it, and the browser sample player
/// reports durations against it). The bank header carries no per-sample rate.
///
/// **This is not part of the key-on pitch.** Retail's voice pitch is a pure
/// function of `note` against the tone's own `center` / `shift`
/// ([`compute_pitch`]), and unity is 44.1 kHz - a 22.05 kHz body is authored
/// with `center` twelve semitones high so the same law lands on `0x800`.
/// Folding this constant into the pitch as well double-counts the
/// resampling and puts every voice - BGM note and sound effect alike - an
/// octave below retail.
pub const VAB_SAMPLE_RATE: u32 = 22_050;

/// Per-VAG metadata after upload: where in SPU RAM the body lives.
#[derive(Debug, Clone, Copy)]
pub struct UploadedVag {
    /// Start address in SPU RAM (bytes).
    pub addr: u32,
    /// Body size in bytes.
    pub size: u32,
}

/// A VAB bank, ready for playback. Holds the per-VAG addresses + program
/// table needed to translate "play program P note N" into voice config.
#[derive(Debug, Clone)]
pub struct VabBank {
    pub master_vol: u8,
    pub samples: Vec<Option<UploadedVag>>,
    /// Per-program table indexed by **program number** - the `ProgAtr` slot
    /// a SEQ ProgramChange or an SFX descriptor names - NOT by packed
    /// tone-page order. The file stores one 16-tone page per *used* program
    /// (`ProgAtr.tones != 0`), packed in slot order; `upload` expands those
    /// pages back into slot space the way retail does at VAB open (see
    /// there): an unused slot aliases onto the next used slot's page, and only
    /// slots past the last used page hold an empty page. Those trailing empties
    /// are trimmed, so `len()` reads "last used program + 1".
    pub programs: Vec<VabProgram>,
}

/// Where a VAB's first VAG body really is, in `bank_buf`'s coordinates.
///
/// Two things have to be resolved here and they used to cancel out, which is
/// why neither was visible.
///
/// **The base.** Callers pass `bank_buf` in one of two conventions: the whole
/// buffer the report was parsed against (so `VagSampleSpan::byte_offset` is a
/// valid index straight away), or that buffer re-sliced at the VAB, in which
/// case every index is `report.header_offset` too large. The `pBAV` magic is
/// the landmark that says which: it is at `header_offset` in the first
/// convention and at 0 in the second.
///
/// **The origin.** A retail VAB is two chunks of a DATA_FIELD stream, and
/// `legaia_vab::parse` walks straight on from the VAG size table onto the body
/// chunk's own 4-byte header - so its spans are four bytes early where the
/// body chunk comes next, and thousands of bytes early where a SEQ chunk
/// intervenes. `legaia_vab::vag_body_origin_at` reads the real origin by
/// walking forward for the chunk whose payload is `fsize - header part`.
///
/// Over the 218 retail stream-carried VABs the two errors cancel exactly on
/// 212: a caller re-slicing at `vab_off = 4` shifts the index forward by the
/// same four bytes the origin is short. On the other six the SEQ chunk sits
/// between the halves, the shifts do not match, and the upload put a slice of
/// the sequence into SPU RAM as a sample body. Resolving both together keeps
/// the 212 byte-identical and fixes the six.
///
/// Returns `(base, delta)`: subtract `base` from a span offset to index
/// `bank_buf`, then add `delta` to reach the real ADPCM grid.
fn body_frame(report: &VabReport, bank_buf: &[u8]) -> (usize, usize) {
    const MAGIC: &[u8; 4] = b"pBAV";
    let at = |o: usize| bank_buf.get(o..o + 4) == Some(&MAGIC[..]);
    let vab_at = if at(report.header_offset) {
        report.header_offset
    } else if at(0) {
        0
    } else {
        // Neither landmark: leave the caller's indexes alone.
        return (0, 0);
    };
    let walked = vab_at + legaia_vab::header_part_size(report.header.ps as usize);
    let delta = legaia_vab::vag_body_origin_at(bank_buf, vab_at)
        .ok()
        .and_then(|o| o.checked_sub(walked))
        .unwrap_or(0);
    (report.header_offset - vab_at, delta)
}

impl VabBank {
    /// Upload every VAG body in `report` into `spu`'s RAM, allocating
    /// through `alloc`. `bank_buf` is either the buffer `legaia_vab::parse`
    /// was given or that buffer re-sliced at the VAB; [`body_frame`] resolves
    /// which, and where the bodies really begin.
    pub fn upload(
        spu: &mut Spu,
        alloc: &mut SpuAllocator,
        report: &VabReport,
        bank_buf: &[u8],
    ) -> Self {
        let (base, delta) = body_frame(report, bank_buf);
        let mut samples: Vec<Option<UploadedVag>> = Vec::with_capacity(report.vag_samples.len());
        spu.ram.set_direction(TransferDirection::CpuToSpu);
        for span in &report.vag_samples {
            if span.size == 0 {
                samples.push(None);
                continue;
            }
            let start = span.byte_offset - base + delta;
            let Some(body) = bank_buf.get(start..start + span.size) else {
                log::warn!(
                    "vab_bind: VAG body {} ({} B at {start:#x}) escapes the {} B bank buffer",
                    span.index,
                    span.size,
                    bank_buf.len()
                );
                samples.push(None);
                continue;
            };
            // Allocate aligned to 16 (one ADPCM block).
            match alloc.alloc(span.size as u32) {
                Some(addr) => {
                    spu.ram.write_at(addr, body);
                    samples.push(Some(UploadedVag {
                        addr,
                        size: span.size as u32,
                    }));
                }
                None => {
                    log::warn!(
                        "vab_bind: SPU RAM exhausted at sample index {} ({} bytes)",
                        span.index,
                        span.size
                    );
                    samples.push(None);
                }
            }
        }
        // Expand the packed tone pages into program-number space. The file's
        // tone region carries one page per *used* program, packed in slot
        // order, so a program number resolves to its page by rank among the
        // used slots.
        //
        // REF: FUN_80068d94 - retail computes exactly this mapping at VAB
        // open: it walks the full ProgAtr table writing the running count of
        // used programs seen so far into each entry's +8 reserved word, and
        // the program-change consumer FUN_80068b98 reads that byte back as
        // the tone-page index. Indexing the packed pages with the raw
        // program number instead mis-tones every program past the first
        // unused slot and drops every program number >= ps outright - on a
        // sparse bank (most music banks) that collapses the whole score onto
        // a few low pages.
        //
        // Retail stores the counter *before* the used check, so a slot's page
        // index is the count of USED slots that precede it: a used slot maps to
        // its own next page, and an UNUSED slot aliases onto the SAME page the
        // next used slot gets. The engine reproduces the page alias (real
        // retail BGM program-changes to gap slots; see
        // tests/real_seq_program_change_coverage.rs), but a *sequencer note*
        // on such a slot still keys nothing: the note-on searches only the
        // slot's own `ProgAtr.tones` rows (`key_tones`, zero here), never the
        // aliased page's. The unused slot keeps its own ProgAtr mvol/mpan.
        //
        // Only the *past-the-last-used-page* case is NOT reproduced: there
        // retail's alias index runs beyond the packed tone region and reads
        // garbage; the engine leaves those trailing slots an empty (silent)
        // page instead of replaying undefined bytes.
        let mut programs = Vec::with_capacity(report.programs.len());
        let mut page = 0usize;
        for prog in &report.programs {
            if page < report.tones.len() {
                programs.push(VabProgram {
                    mvol: prog.mvol,
                    mpan: prog.mpan,
                    tones: report.tones[page].clone(),
                    key_tones: prog.tones,
                });
                // Only a used slot advances the page counter; an unused slot
                // shares the page of the used slot that follows it.
                if prog.tones != 0 {
                    page += 1;
                }
            } else {
                programs.push(VabProgram {
                    mvol: 0x7F,
                    mpan: 0x40,
                    tones: Vec::new(),
                    key_tones: 0,
                });
            }
        }
        while programs.last().is_some_and(|p| p.tones.is_empty()) {
            programs.pop();
        }
        Self {
            master_vol: report.header.mvol,
            samples,
            programs,
        }
    }

    /// Play `note` (MIDI key, 0..=127) through `program` index using `voice`
    /// on the SPU. Velocity 0..=127 scales the per-tone volume.
    ///
    /// Returns `false` when the program / tone / sample isn't valid (so the
    /// engine can log + skip without panicking on bad bank data).
    pub fn play_note(
        &self,
        spu: &mut Spu,
        voice: usize,
        program: usize,
        note: u8,
        velocity: u8,
    ) -> bool {
        let Some(prog) = self.programs.get(program) else {
            return false;
        };
        let Some(tone) = prog
            .key_range_tones()
            .iter()
            .find(|t| note >= t.min && note <= t.max)
        else {
            return false;
        };
        self.fire(
            spu,
            voice,
            prog,
            tone,
            note,
            velocity,
            0x40,
            PitchPath::Sequencer,
        )
    }

    /// Play the tone at an **explicit index** inside `program`, rather than
    /// resolving it by key range the way [`Self::play_note`] does.
    ///
    /// This is the shape of the retail *SFX* path, which differs from the
    /// sequencer's: the SFX descriptor's `+1` byte names the ADSR region
    /// directly (`FUN_80065034` is handed program `+0`, region `+1` `+ i`, and
    /// the note-level attribute `+2`), so a cue's tone is an index, and a
    /// multi-voice cue walks consecutive regions. Key-range resolution would
    /// silently miss those cues whose descriptor note falls outside the tone's
    /// authored `min..=max` window (several retail cues do, e.g. the generic
    /// strike cue `0x1A`). See `docs/formats/sfx-table.md`.
    ///
    /// Returns `false` when the program / tone / sample isn't valid.
    pub fn play_tone(
        &self,
        spu: &mut Spu,
        voice: usize,
        program: usize,
        tone_index: usize,
        note: u8,
        velocity: u8,
    ) -> bool {
        let Some(prog) = self.programs.get(program) else {
            return false;
        };
        let Some(tone) = prog.tones.get(tone_index) else {
            return false;
        };
        self.fire(spu, voice, prog, tone, note, velocity, 0x40, PitchPath::Cue)
    }

    /// [`Self::play_tone`] from a cue's **volume pair**, the way `FUN_80065034`
    /// takes it (`sp+0x58` / `sp+0x5C`): the larger half is the velocity and
    /// the ratio of the two is a staged pan (`0x80065100..0x80065118`) - `0x40`
    /// for equal halves, `(r << 6) / l` when the right is smaller,
    /// `0x7F - (l << 6) / r` when the left is - which the key-on chain
    /// `FUN_80067550` applies as its third pan stage after the tone and
    /// program pans. Equal halves (every ring cue) are exactly
    /// [`Self::play_tone`].
    ///
    /// PORT: FUN_80065034 (the volume-pair split)
    #[allow(clippy::too_many_arguments)]
    pub fn play_tone_pair(
        &self,
        spu: &mut Spu,
        voice: usize,
        program: usize,
        tone_index: usize,
        note: u8,
        vol_l: i16,
        vol_r: i16,
    ) -> bool {
        let Some(prog) = self.programs.get(program) else {
            return false;
        };
        let Some(tone) = prog.tones.get(tone_index) else {
            return false;
        };
        let (velocity, pan) = cue_volume_pair(vol_l, vol_r);
        self.fire(spu, voice, prog, tone, note, velocity, pan, PitchPath::Cue)
    }

    /// Configure + key on `voice` for one resolved tone. Shared by
    /// [`Self::play_note`] (key-range lookup, [`PitchPath::Sequencer`]) and
    /// [`Self::play_tone`] (explicit region index, [`PitchPath::Cue`]).
    #[allow(clippy::too_many_arguments)]
    fn fire(
        &self,
        spu: &mut Spu,
        voice: usize,
        prog: &VabProgram,
        tone: &legaia_vab::VagAtr,
        note: u8,
        velocity: u8,
        stage_pan: i32,
        path: PitchPath,
    ) -> bool {
        // tone.vag is 1-based in PSX VAB format. legaia_vab::VabReport's
        // `vag_samples` is 0-indexed (samples[0..vs]), so subtract 1.
        if tone.vag <= 0 {
            return false;
        }
        let sample_idx = (tone.vag - 1) as usize;
        let Some(Some(vag)) = self.samples.get(sample_idx) else {
            return false;
        };
        if voice >= spu.voices.len() {
            return false;
        }
        let pitch = compute_pitch(note, tone, path);
        // PORT: FUN_80067550 (head) - the key-on volume chain, retail's
        // staged integer arithmetic with its truncation points:
        //
        //   step = vel * bank_mvol * 0x3FFF / 0x3F01
        //   vol  = step * prog_mvol * tone_vol / 0x3F01
        //
        // Four 0..=127 factors (velocity, bank master, program master, tone)
        // against 127^2 twice widen the product into the SPU's 14-bit
        // register domain; a full-scale product lands exactly on 0x3FFF.
        // All intermediates fit i32 (max 0x3FFF * 127 * 127 < 2^31).
        let vel = velocity as i32;
        let bank_master = self.master_vol as i32;
        let step = (vel * bank_master * 0x3FFF) / 0x3F01;
        let combined = ((step * prog.mvol as i32 * tone.vol as i32) / 0x3F01).min(0x3FFF) as i16;
        // Retail attenuates once per pan source, in order: tone pan, then
        // program pan. The channel pan is the sequencer's own source,
        // applied on top by `channel_mix`.
        let (l, r) = pan_split(combined, tone.pan as i32);
        let (l, r) = pan_attenuate(l, r, prog.mpan as i32);
        // The cue path's third stage: the pan staged from its volume pair
        // (`0x40`, a no-op, for the sequencer and every equal pair).
        let (vol_l, vol_r) = if stage_pan == 0x40 {
            (l, r)
        } else {
            pan_attenuate(l, r, stage_pan)
        };
        {
            let v = &mut spu.voices[voice];
            v.start_addr = vag.addr;
            v.loop_addr = None;
            v.pitch = pitch;
            v.vol_left = vol_l;
            v.vol_right = vol_r;
            v.adsr_cfg = AdsrConfig::from_words(tone.adsr1, tone.adsr2);
            // PORT: FUN_80067550 (tail, 0x80067940..0x800679B4) - every
            // key-on, sequencer note and cue alike, sets or clears this
            // voice's bit in the staged reverb-enable mask (`EON`,
            // `0x801CDB4C/4E`) from the tone's `mode` byte: bit 2 routes the
            // voice into the reverb, a clear bit plays it dry. Reverb is per
            // tone, not a global all-voices routing - most battle hit tones
            // are authored dry.
            v.reverb_send = tone_reverb(tone);
            // Engine mix bus: a sequencer note is music, a cue key-on is a
            // sound effect (the config file's `bgm_volume` / `sfx_volume`).
            v.bus = match path {
                PitchPath::Sequencer => crate::spu::VoiceBus::Bgm,
                PitchPath::Cue => crate::spu::VoiceBus::Sfx,
            };
        }
        {
            let crate::spu::Spu {
                ref mut voices,
                ref ram,
                ..
            } = *spu;
            voices[voice].key_on(ram);
        }
        spu.record_key_on(voice);
        true
    }

    /// The tone that would be selected for `(program, note)` carries a
    /// pitch-bend range in the VAB attributes: `pbmin` semitones of downward
    /// bend at full-down wheel, `pbmax` semitones up at full-up. Returns
    /// `(pbmin, pbmax)` so the sequencer can scale a `0xEn` wheel value by the
    /// note's own range (a tone with `(0, 0)` does not respond to the wheel).
    /// `(0, 0)` is also the fallback when the program/tone can't be resolved.
    pub fn pitch_bend_range(&self, program: usize, note: u8) -> (u8, u8) {
        self.programs
            .get(program)
            .and_then(|p| {
                p.key_range_tones()
                    .iter()
                    .find(|t| note >= t.min && note <= t.max)
            })
            .map(|t| (t.pbmin, t.pbmax))
            .unwrap_or((0, 0))
    }

    /// The VAB `prior` byte of the tone that would be selected for
    /// `(program, note)` - the note's requested **allocation priority**.
    ///
    /// Retail stages this byte (VagAtr `+0` of the resolved tone) into the
    /// driver's note-staging block before running the voice-allocation scan,
    /// where it seeds the steal threshold: only sounding voices whose own
    /// priority is `<=` the request may be stolen. `None` when the program /
    /// tone doesn't resolve (the note would not key on at all).
    ///
    /// REF: FUN_80066308 (stages the tone attrs), FUN_80066B00 (consumes the
    /// staged priority as the scan threshold).
    pub fn tone_prior(&self, program: usize, note: u8) -> Option<u8> {
        self.programs
            .get(program)
            .and_then(|p| {
                p.key_range_tones()
                    .iter()
                    .find(|t| note >= t.min && note <= t.max)
            })
            .map(|t| t.prior)
    }

    /// Whether `(program, note)` would actually key on a voice - i.e. it
    /// resolves to a tone whose sample is present and uploaded. This is the
    /// exact success condition of [`Self::fire`] (tone found by key range,
    /// `vag > 0`, sample resident), computed without a voice or side effects.
    ///
    /// The sequencer calls this **before** allocating a voice: a note that
    /// can't sound (empty tone slot, or a sample that didn't fit in SPU RAM)
    /// must not steal a voice that is currently sounding, or the steal drops
    /// an audible note in exchange for silence.
    pub fn can_play(&self, program: usize, note: u8) -> bool {
        let Some(prog) = self.programs.get(program) else {
            return false;
        };
        let Some(tone) = prog
            .key_range_tones()
            .iter()
            .find(|t| note >= t.min && note <= t.max)
        else {
            return false;
        };
        self.tone_resident(tone)
    }

    /// Every tone of `program` whose key range covers `note`, as tone
    /// indices in program order - the **layer set** one sequencer note-on
    /// keys. A program may stack several tones over one key (a two-sample
    /// instrument); retail keys one voice per covering tone, not just the
    /// first.
    ///
    /// REF: FUN_80068568 - walks the program's tones on its page and, for
    /// each with `min (+6) <= note <= max (+7)`, records the tone index and
    /// its VAG id; `FUN_80066308` then runs the allocation scan and the key-on
    /// once per recorded tone (`0x800664F0..0x8006684C`), a failed scan
    /// skipping only that layer.
    pub fn layer_tones(&self, program: usize, note: u8) -> Vec<usize> {
        self.programs
            .get(program)
            .map(|p| {
                p.key_range_tones()
                    .iter()
                    .enumerate()
                    .filter(|(_, t)| note >= t.min && note <= t.max)
                    .map(|(i, _)| i)
                    .collect()
            })
            .unwrap_or_default()
    }

    /// [`Self::tone_prior`] for an explicit tone index.
    pub fn tone_prior_at(&self, program: usize, tone_index: usize) -> Option<u8> {
        self.tone_at(program, tone_index).map(|t| t.prior)
    }

    /// [`Self::can_play`] for an explicit tone index.
    pub fn can_play_tone(&self, program: usize, tone_index: usize) -> bool {
        self.tone_at(program, tone_index)
            .is_some_and(|t| self.tone_resident(t))
    }

    /// [`Self::pitch_bend_range`] for an explicit tone index.
    pub fn pitch_bend_range_at(&self, program: usize, tone_index: usize) -> (u8, u8) {
        self.tone_at(program, tone_index)
            .map(|t| (t.pbmin, t.pbmax))
            .unwrap_or((0, 0))
    }

    /// Key one **layer** of a sequencer note: the tone at `tone_index` of
    /// `program`, pitched on the sequencer arm. [`Self::play_note`] is the
    /// first-layer special case.
    pub fn play_note_layer(
        &self,
        spu: &mut Spu,
        voice: usize,
        program: usize,
        tone_index: usize,
        note: u8,
        velocity: u8,
    ) -> bool {
        let Some(prog) = self.programs.get(program) else {
            return false;
        };
        let Some(tone) = prog.tones.get(tone_index) else {
            return false;
        };
        self.fire(
            spu,
            voice,
            prog,
            tone,
            note,
            velocity,
            0x40,
            PitchPath::Sequencer,
        )
    }

    /// The head of `FUN_80067550` for a sequencer note on layer `tone_index`
    /// of `program`, carried through the sequence volume and the tone and
    /// program pans, in retail's order and integer steps:
    ///
    /// 1. `vel * (bank_mvol * 0x3FFF) / 0x3F01` (signed, `0x80067550..9C`);
    /// 2. `* prog_mvol * tone_vol / 0x3F01` (`..0x800675F4`);
    /// 3. `* seq_vol / 0x7F` per side (`0x8006763C..0x80067698`);
    /// 4. the tone pan, then the program pan - each attenuating its far side
    ///    by `pan / 63` or `(0x7F - pan) / 63` (`0x8006769C..0x80067780`).
    ///
    /// `velocity` is the effective one (CC7 already folded in). The channel
    /// pan and square taper follow in the sequencer. `None` when the tone
    /// does not resolve.
    pub fn seq_note_volume(
        &self,
        program: usize,
        tone_index: usize,
        velocity: u8,
        seq_vol: u8,
    ) -> Option<(i16, i16)> {
        let prog = self.programs.get(program)?;
        let tone = prog.tones.get(tone_index)?;
        let head = (velocity as i32 * (self.master_vol as i32 * 0x3FFF)) / 0x3F01;
        let head = (head as u32 * prog.mvol as u32 * tone.vol as u32) / 0x3F01;
        let side = (head * seq_vol.min(127) as u32 / 0x7F) as i16;
        let (l, r) = pan_attenuate(side, side, tone.pan as i32);
        Some(pan_attenuate(l, r, prog.mpan as i32))
    }

    fn tone_at(&self, program: usize, tone_index: usize) -> Option<&VagAtr> {
        self.programs.get(program)?.tones.get(tone_index)
    }

    fn tone_resident(&self, tone: &VagAtr) -> bool {
        tone.vag > 0 && matches!(self.samples.get((tone.vag - 1) as usize), Some(Some(_)))
    }
}

/// The VAB tone `mode` bit that routes a keyed voice into the reverb.
pub const TONE_MODE_REVERB: u8 = 0x04;

/// Whether a voice keyed from `tone` is sent to the reverb: `mode & 4`, the
/// test `FUN_80067550` applies at `0x80067944..0x8006794C` before setting or
/// clearing the voice's `EON` bit.
pub fn tone_reverb(tone: &VagAtr) -> bool {
    tone.mode & TONE_MODE_REVERB != 0
}

/// Entries in retail's note-to-pitch table: 12 semitones x 16 sixteenth-of-a
/// -semitone fine steps, i.e. one octave at 1/16-semitone resolution.
const PITCH_TABLE_LEN: i32 = 192;

/// The fine-tune value every retail SFX / direct key-on call site passes.
///
/// `FUN_80065034`'s sixth argument is a `fine` in 1/128-semitone units, and it
/// is the literal `0x40` at every traced call site - the cue-ring drainer
/// `FUN_80016B6C` (both its one-shot and sustained arms), the per-actor trigger
/// under `FUN_80021DF4`, and the minigame overlays' direct key-ons. So a cue
/// plays a **half semitone above** where the sequencer would put the same
/// `(tone, note)` pair. It is a constant, not a parameter, hence no argument
/// for it here.
const CUE_FINE: u32 = 0x40;

/// One entry of retail's note-to-pitch table (`DAT_8007A940` in
/// `SCUS_942.54`, 192 x `u16`, also resident in RAM at that VA).
///
/// The table is exactly `floor(0x1000 * 2^(k / 192))` for all 192 entries -
/// verified entry-by-entry against the executable's rodata - so the port
/// computes it instead of carrying a copy. No entry lands closer than 0.004 to
/// an integer, so the `floor` is not sensitive to `exp2` rounding.
fn pitch_table_entry(index: i32) -> u32 {
    let k = index.clamp(0, PITCH_TABLE_LEN - 1);
    ((PITCH_UNITY as f64) * (k as f64 / PITCH_TABLE_LEN as f64).exp2()).floor() as u32
}

/// Which of retail's two key-on paths is computing the pitch. They share the
/// table and the octave shift and differ only in how the fine index is formed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PitchPath {
    /// Sequencer note-on (`FUN_80066308` -> `FUN_80066d8c`). The fine index is
    /// the tone's own `shift` alone, `min(shift >> 3, 15)`, and it can never
    /// carry into the semitone: a tone with `shift = 0xFF` is pinned at
    /// +15/16 of a semitone.
    Sequencer,
    /// SFX / direct key-on (`FUN_80065034` -> `FUN_80066e50`). The index is
    /// `(0x40 + shift) >> 3` ([`CUE_FINE`]) with **no** clamp; a value of 16 or
    /// more instead carries one whole semitone and keeps the remainder.
    Cue,
}

/// Compute the SPU pitch register value for `note` against `tone.center` and
/// `tone.shift`, exactly as retail's libsnd does.
///
/// ```text
///   fine, carry = per-path from tone.shift        (see PitchPath)
///   n           = note + 60 - tone.center + carry
///   pitch       = table[(n % 12) * 16 + fine] shifted by (n / 12 - 5)
/// ```
///
/// `n == 60` (`note == center`) selects `table[0] = 0x1000`, so a tone plays
/// its body back at 44.1 kHz at its own centre note; each semitone away
/// scales by `2^(1/12)`, in whole octaves by a register shift. `shift` moves
/// the pitch **up** by `shift/128` of a semitone (quantised to 1/16), which is
/// the opposite sign and a different scale from the "centi-semitone"
/// interpretation this function used to carry.
///
/// `n / 12` and `n % 12` truncate toward zero, matching MIPS `div`. For
/// `n < 0` - a note more than five octaves under the tone's centre, which no
/// disc-authored pair reaches - the remainder goes negative and retail reads
/// off the front of its own table; the port clamps the index instead.
///
/// PORT: FUN_80066d8c (sequencer arm), FUN_80066e50 (cue arm, partial)
///
/// The cue arm's `fine` argument (`andi a1,a1,0xffff` at `0x80066e7c`) is
/// fixed at `CUE_FINE` rather than taken from the caller.
fn compute_pitch(note: u8, tone: &VagAtr, path: PitchPath) -> u16 {
    let shift = tone.shift as u32;
    let (semitone_carry, fine_index) = match path {
        PitchPath::Sequencer => (0i32, ((shift >> 3) as i32).min(15)),
        PitchPath::Cue => {
            let raw = ((CUE_FINE + shift) >> 3) as i32;
            if raw >= 16 { (1, raw - 16) } else { (0, raw) }
        }
    };
    let n = note as i32 + 60 - tone.center as i32 + semitone_carry;
    let octave = n / 12 - 5;
    let mut pitch = pitch_table_entry((n % 12) * 16 + fine_index);
    if octave > 0 {
        // Retail shifts a 16-bit value and stores 16 bits back: an octave-up
        // that overflows wraps rather than saturating.
        pitch = (pitch << octave.min(31)) & 0xFFFF;
    } else if octave < 0 {
        pitch >>= (-octave).min(31);
    }
    // Hardware clamps the pitch-counter step at 0x4000 (4.0x / 176.4 kHz).
    pitch.clamp(1, 0x4000) as u16
}

/// Split a combined volume into (left, right) for a tone's 0..=127 pan value
/// (0x40 = centre), using libsnd's voice-volume pan law (`FUN_80067550`): a
/// pan left of centre attenuates the **right** by `pan/0x3f`, a pan right of
/// centre attenuates the **left** by `(0x7f - pan)/0x3f`. The near side is
/// left alone - the law only ever attenuates, so it cannot overflow the
/// register.
///
/// This is the same law `sequencer::apply_channel_pan` already applies to the
/// CC10 channel pan, and deliberately so: libsnd runs this attenuation once
/// per pan source (channel / sequence / tone), so both sources must share it.
///
/// The earlier form here scaled both sides by `/64`, which BOOSTS the near
/// side to ~2x and clamps. That was invisible while key-on volume was stuck
/// in 0..=127 - the clamp was unreachable - but at the correct 0..=0x3FFF
/// scale 836 of the 7724 retail tones would have hit it at full velocity
/// (census in tests/real_vab_tone_attributes.rs). Widening the volume without
/// fixing the pan law would have traded a quiet engine for a clipping one.
/// `FUN_80065034`'s split of a cue's volume pair into the velocity and the
/// staged pan its key-on chain reads (`DAT_801CE34C` / `DAT_801CE34D`).
/// Each half is clamped into `0..=127` first, the domain the callers compute.
pub fn cue_volume_pair(vol_l: i16, vol_r: i16) -> (u8, i32) {
    let l = i32::from(vol_l).clamp(0, 127);
    let r = i32::from(vol_r).clamp(0, 127);
    if l == r {
        (l as u8, 0x40)
    } else if r < l {
        (l as u8, (r << 6) / l)
    } else {
        (r as u8, 0x7F - (l << 6) / r)
    }
}

fn pan_split(vol: i16, pan: i32) -> (i16, i16) {
    pan_attenuate(vol, vol, pan)
}

/// One application of the same pan law over an already-split `(left, right)`
/// pair. Retail runs this once per pan source in order - tone pan, then
/// program pan (`ProgAtr.mpan`), then the sequencer's channel pan - each
/// stage only ever attenuating its far side.
fn pan_attenuate(left: i16, right: i16, pan: i32) -> (i16, i16) {
    let pan = pan.clamp(0, 0x7f);
    if pan < 0x40 {
        (left, (right as i32 * pan / 0x3f) as i16)
    } else {
        ((left as i32 * (0x7f - pan) / 0x3f) as i16, right)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn dummy_tone(center: u8, vag: i16, vol: u8, pan: u8) -> VagAtr {
        VagAtr {
            prior: 0,
            mode: 0,
            vol,
            pan,
            center,
            shift: 0,
            min: 0,
            max: 127,
            vibw: 0,
            vibt: 0,
            porw: 0,
            port: 0,
            pbmin: 0,
            pbmax: 0,
            reserved1: 0,
            reserved2: 0,
            adsr1: 0,
            adsr2: 0,
            prog: 0,
            vag,
            reserved3: [0; 4],
        }
    }

    fn tone_with_shift(center: u8, shift: u8) -> VagAtr {
        VagAtr {
            shift,
            ..dummy_tone(center, 1, 127, 64)
        }
    }

    /// A note at the tone's centre plays at **unity** - 0x1000, 44.1 kHz - not
    /// at a source/dest sample-rate ratio. This is the whole defect that put
    /// every voice an octave low: retail's table entry 0 is 0x1000, and the
    /// sample's own rate is already encoded in `center`.
    #[test]
    fn pitch_at_center_is_unity_not_the_vag_sample_rate_ratio() {
        let tone = dummy_tone(60, 1, 127, 64);
        assert_eq!(compute_pitch(60, &tone, PitchPath::Sequencer), 0x1000);
        assert_ne!(
            compute_pitch(60, &tone, PitchPath::Sequencer),
            0x800,
            "0x800 is the 22050/44100 double-count, not retail's unity"
        );
    }

    /// One semitone above center bumps pitch by 2^(1/12) ≈ 1.0595; one octave
    /// doubles it exactly (retail shifts the register rather than multiplying).
    #[test]
    fn pitch_one_semitone_above_is_higher() {
        let tone = dummy_tone(60, 1, 127, 64);
        let p_center = compute_pitch(60, &tone, PitchPath::Sequencer);
        let p_above = compute_pitch(61, &tone, PitchPath::Sequencer);
        assert!(p_above > p_center);
        let ratio = p_above as f64 / p_center as f64;
        assert!((ratio - 2f64.powf(1.0 / 12.0)).abs() < 0.001);
        assert_eq!(compute_pitch(72, &tone, PitchPath::Sequencer), 0x2000);
        assert_eq!(compute_pitch(48, &tone, PitchPath::Sequencer), 0x800);
    }

    /// The 192-entry table retail indexes is `floor(0x1000 * 2^(k/192))` - a
    /// closed form, which is why the port computes it instead of carrying a
    /// copy of the executable's rodata. Endpoints and monotonicity pinned.
    #[test]
    fn pitch_table_is_the_closed_form_retail_carries() {
        assert_eq!(pitch_table_entry(0), 0x1000);
        assert_eq!(pitch_table_entry(PITCH_TABLE_LEN - 1), 8162);
        for k in 0..PITCH_TABLE_LEN {
            let want = (4096.0_f64 * (k as f64 / 192.0).exp2()).floor() as u32;
            assert_eq!(pitch_table_entry(k), want, "table entry {k}");
            if k > 0 {
                assert!(pitch_table_entry(k) > pitch_table_entry(k - 1));
            }
        }
        // One octave up from entry 0 must not have been reached yet - the
        // table spans an open octave and the register shift covers the rest.
        assert!(pitch_table_entry(PITCH_TABLE_LEN - 1) < 0x2000);
    }

    /// `shift` moves the pitch **up** by `shift/128` of a semitone, quantised
    /// to 1/16, and the sequencer arm clamps the index at 15 rather than
    /// carrying. The old reading (`- shift/100` semitones) had both the sign
    /// and the scale wrong.
    #[test]
    fn shift_raises_pitch_by_sixteenths_of_a_semitone() {
        let flat = tone_with_shift(60, 0);
        let sharp = tone_with_shift(60, 64);
        assert_eq!(compute_pitch(60, &flat, PitchPath::Sequencer), 0x1000);
        // 64 >> 3 = 8 -> half a semitone up -> table entry 8.
        assert_eq!(
            compute_pitch(60, &sharp, PitchPath::Sequencer),
            pitch_table_entry(8) as u16
        );
        assert!(
            compute_pitch(60, &sharp, PitchPath::Sequencer)
                > compute_pitch(60, &flat, PitchPath::Sequencer)
        );
        // The sequencer arm saturates at 15/16 of a semitone: 0xFF >> 3 = 31
        // clamps to 15, and never carries into the next semitone.
        let extreme = tone_with_shift(60, 0xFF);
        assert_eq!(
            compute_pitch(60, &extreme, PitchPath::Sequencer),
            pitch_table_entry(15) as u16
        );
    }

    /// A cue keys on half a semitone above where the sequencer would put the
    /// same tone, because every retail SFX call site passes `fine = 0x40`.
    #[test]
    fn cue_path_sits_a_half_semitone_above_the_sequencer_path() {
        let tone = dummy_tone(60, 1, 127, 64);
        assert_eq!(
            compute_pitch(60, &tone, PitchPath::Cue),
            pitch_table_entry(8) as u16
        );
        // With shift >= 0x40 the cue arm carries a whole semitone instead of
        // clamping, so it keeps climbing where the sequencer arm has stopped.
        let sharp = tone_with_shift(60, 0x40);
        assert_eq!(
            compute_pitch(60, &sharp, PitchPath::Cue),
            pitch_table_entry(16) as u16
        );
        assert_eq!(
            compute_pitch(60, &sharp, PitchPath::Cue),
            compute_pitch(61, &tone, PitchPath::Sequencer),
            "0x40 fine + 0x40 shift is exactly one semitone"
        );
    }

    /// Anchors read out of retail's own libsnd note-staging block in mednafen
    /// save states: `(note, center, shift)` against the pitch the driver had
    /// already written to the voice. The sequencer rows are BGM notes, the cue
    /// row is the pause-menu cursor blip (program 0 / tone 1 / note 61).
    #[test]
    fn pitch_matches_values_captured_from_retail() {
        for (note, center, shift, path, want) in [
            (64u8, 72u8, 0u8, PitchPath::Sequencer, 2580u16),
            (52, 68, 54, PitchPath::Sequencer, 1661),
            (57, 68, 124, PitchPath::Sequencer, 2290),
            (33, 60, 30, PitchPath::Sequencer, 870),
            (78, 73, 70, PitchPath::Sequencer, 5627),
            (64, 86, 0, PitchPath::Cue, 1183),
            (61, 85, 59, PitchPath::Cue, 1080),
            (60, 72, 59, PitchPath::Cue, 2161),
        ] {
            let tone = tone_with_shift(center, shift);
            assert_eq!(
                compute_pitch(note, &tone, path),
                want,
                "note {note} center {center} shift {shift} {path:?}"
            );
        }
    }

    /// `FUN_80065034`'s split of a cue's volume pair.
    #[test]
    fn cue_volume_pair_takes_the_larger_half_and_stages_the_ratio_as_pan() {
        // Equal halves: the volume once, centre pan.
        assert_eq!(cue_volume_pair(100, 100), (100, 0x40));
        // Right smaller: `(r << 6) / l`; left smaller: `0x7F - (l << 6) / r`.
        assert_eq!(cue_volume_pair(100, 50), (100, 32));
        assert_eq!(cue_volume_pair(50, 100), (100, 0x7F - 32));
        assert_eq!(cue_volume_pair(0, 0), (0, 0x40));
    }

    /// Pan=0 silences right; pan=127 silences left; pan=64 is roughly equal.
    #[test]
    fn pan_split_endpoints_silence_opposite_side() {
        let (l, r) = pan_split(0x3FFF, 0);
        assert!(l > 0);
        assert_eq!(r, 0);
        let (l, r) = pan_split(0x3FFF, 127);
        assert_eq!(l, 0);
        assert!(r > 0);
        let (l, r) = pan_split(0x3FFF, 64);
        // Center pan: left ≈ vol * 63/64, right = vol. Difference is ~vol/64.
        assert!((l as i32 - r as i32).abs() <= 0x100);
    }

    /// VabBank::play_note returns false for an invalid program index without
    /// panicking; voice state is left untouched.
    #[test]
    fn play_note_invalid_program_returns_false() {
        let mut spu = Spu::new();
        let bank = VabBank {
            master_vol: 127,
            samples: vec![],
            programs: vec![],
        };
        let ok = bank.play_note(&mut spu, 0, 99, 60, 100);
        assert!(!ok);
        // Voice 0 still in default Off state.
        assert!(spu.voices[0].is_off());
    }

    /// `can_play` mirrors `fire`'s success condition exactly: it is true only
    /// when the tone resolves AND its sample is resident. A resolved tone whose
    /// sample slot is missing/empty, or whose `vag` is out of range, is false -
    /// which is what keeps the sequencer from stealing a voice for a note that
    /// would then fail to sound.
    #[test]
    fn can_play_tracks_sample_residency() {
        let uploaded = UploadedVag { addr: 0, size: 16 };
        // Program 0 tone points at sample 1 (1-based vag); program 1 at sample 2.
        let bank = VabBank {
            master_vol: 127,
            // Sample index 0 present (backs vag=1), index 1 absent (backs vag=2).
            samples: vec![Some(uploaded), None],
            programs: vec![
                VabProgram {
                    mvol: 127,
                    mpan: 0x40,
                    tones: vec![dummy_tone(60, 1, 100, 0x40)],
                    key_tones: legaia_vab::TONES_PER_PROGRAM as u8,
                },
                VabProgram {
                    mvol: 127,
                    mpan: 0x40,
                    tones: vec![dummy_tone(60, 2, 100, 0x40)],
                    key_tones: legaia_vab::TONES_PER_PROGRAM as u8,
                },
            ],
        };
        // Resolves and sample resident -> playable, and consistent with play_note.
        assert!(bank.can_play(0, 60));
        let mut spu = Spu::new();
        assert!(bank.play_note(&mut spu, 0, 0, 60, 100));
        // Resolves but sample absent -> not playable (would steal-then-fail).
        assert!(!bank.can_play(1, 60));
        let mut spu = Spu::new();
        assert!(!bank.play_note(&mut spu, 0, 1, 60, 100));
        // Program out of range -> not playable.
        assert!(!bank.can_play(9, 60));
    }

    /// A key-on routes the voice into the reverb exactly when the tone's
    /// `mode & 4` is set, and clears the send otherwise - so a dry tone keyed
    /// on a voice a wet one used last plays dry. Both key-on arms share it.
    #[test]
    fn key_on_reverb_send_follows_tone_mode_bit_2() {
        let uploaded = UploadedVag { addr: 0, size: 16 };
        let wet = VagAtr {
            mode: TONE_MODE_REVERB,
            ..dummy_tone(60, 1, 100, 0x40)
        };
        let dry = dummy_tone(60, 1, 100, 0x40);
        let bank = VabBank {
            master_vol: 127,
            samples: vec![Some(uploaded)],
            programs: vec![VabProgram {
                mvol: 127,
                mpan: 0x40,
                tones: vec![wet, dry],
                key_tones: legaia_vab::TONES_PER_PROGRAM as u8,
            }],
        };
        let mut spu = Spu::new();
        assert!(bank.play_tone(&mut spu, 5, 0, 0, 60, 100));
        assert!(spu.voices[5].reverb_send);
        assert!(bank.play_tone(&mut spu, 5, 0, 1, 60, 100));
        assert!(!spu.voices[5].reverb_send);
        // Sequencer arm: key range resolves the first (wet) tone.
        assert!(bank.play_note(&mut spu, 5, 0, 60, 100));
        assert!(spu.voices[5].reverb_send);
    }

    fn prog(tones: u8, mvol: u8) -> legaia_vab::ProgAtr {
        legaia_vab::ProgAtr {
            tones,
            mvol,
            prior: 0,
            mode: 0,
            mpan: 0x40,
            reserved0: 0,
            attr: 0,
            reserved1: 0,
            reserved2: 0,
        }
    }

    fn mk_report(
        progs: Vec<legaia_vab::ProgAtr>,
        tones: Vec<Vec<VagAtr>>,
    ) -> legaia_vab::VabReport {
        legaia_vab::VabReport {
            header: legaia_vab::VabHeader {
                magic: 0,
                version: 0,
                vab_id: 0,
                fsize: 0,
                ps: tones.len() as u16,
                ts: 0,
                vs: 0,
                mvol: 127,
                pan: 0x40,
                attr1: 0,
                attr2: 0,
            },
            header_offset: 0,
            programs: progs,
            tones,
            vag_samples: vec![],
            vag_table_spacer: 0,
        }
    }

    /// A ProgramChange to an UNUSED program slot aliases onto the next used
    /// slot's tone page (retail's `+8` used-counter is written before the used
    /// check), keeping the unused slot's own `mvol`; a slot past the last used
    /// page stays empty (retail reads garbage there, which we don't replay).
    #[test]
    fn unused_slot_program_aliases_to_next_used_page() {
        // Slots: used, UNUSED, used, unused(trailing). Two used -> two packed
        // pages, made distinguishable by tone `center` (10 = page A, 20 = B).
        let page_a = vec![dummy_tone(10, 1, 100, 0x40)];
        let page_b = vec![dummy_tone(20, 1, 100, 0x40)];
        let report = mk_report(
            vec![
                prog(1, 0x70), // slot 0 used   -> page A
                prog(0, 0x55), // slot 1 UNUSED -> aliases to slot 2's page (B)
                prog(1, 0x60), // slot 2 used   -> page B
                prog(0, 0x40), // slot 3 unused, trailing -> past region -> empty
            ],
            vec![page_a, page_b],
        );
        let mut spu = Spu::new();
        let mut alloc = crate::spu::ram::SpuAllocator::new(0x1000, 0x1_0000);
        let bank = VabBank::upload(&mut spu, &mut alloc, &report, &[]);

        // Used slots keep their own next page.
        assert_eq!(bank.programs[0].tones[0].center, 10, "slot 0 = page A");
        assert_eq!(bank.programs[2].tones[0].center, 20, "slot 2 = page B");
        // THE FIX: the unused in-range slot resolves to the next used slot's
        // page (B) instead of silence, and keeps its OWN ProgAtr mvol.
        assert_eq!(bank.programs[1].tones.len(), 1, "slot 1 aliased, not empty");
        assert_eq!(bank.programs[1].tones[0].center, 20, "slot 1 -> page B");
        assert_eq!(bank.programs[1].mvol, 0x55, "slot 1 keeps its own mvol");
        // The trailing unused slot is past the last used page -> empty ->
        // trimmed off the tail, so the bank ends at the last used slot.
        assert_eq!(bank.programs.len(), 3, "trailing empty slot trimmed");
    }

    /// Build a synthetic `[chunk0 hdr][VAB header part][mid chunks][bodies]`
    /// stream. `mid` is an extra chunk between the halves, as six retail
    /// entries carry (their SEQ); its payload is `0xEE` so a mis-resolved
    /// origin shows up as the wrong byte.
    fn stream_with(ps: usize, body: &[u8], mid: usize) -> Vec<u8> {
        let hps = legaia_vab::header_part_size(ps);
        let mut v = Vec::new();
        v.extend_from_slice(&((hps as u32).to_le_bytes()));
        // VAB header part: magic, version, id, fsize, then ps / vs.
        let mut head = vec![0u8; hps];
        head[0..4].copy_from_slice(b"pBAV");
        head[4..8].copy_from_slice(&7u32.to_le_bytes());
        head[12..16].copy_from_slice(&((hps + body.len()) as u32).to_le_bytes());
        head[0x12..0x14].copy_from_slice(&(ps as u16).to_le_bytes());
        head[0x16..0x18].copy_from_slice(&1u16.to_le_bytes());
        // VAG size table entry 1 = the one sample, in 8-byte units.
        let table = 0x20 + 0x800 + 0x200 * ps;
        head[table + 2..table + 4].copy_from_slice(&((body.len() / 8) as u16).to_le_bytes());
        v.extend_from_slice(&head);
        if mid > 0 {
            v.extend_from_slice(&(0x0200_0000u32 | mid as u32).to_le_bytes());
            v.extend(std::iter::repeat_n(0xEEu8, mid));
        }
        v.extend_from_slice(&(0x0100_0000u32 | body.len() as u32).to_le_bytes());
        v.extend_from_slice(body);
        v
    }

    /// The upload finds the same bytes whichever buffer convention it is
    /// handed, and finds them past an intervening chunk.
    ///
    /// Both halves of the old arithmetic were wrong and cancelled: a caller
    /// re-slicing at the VAB indexed four bytes too far on, which is exactly
    /// what the parsed origin was short. This pins the resolution instead of
    /// the cancellation - the same body bytes reach SPU RAM from the whole
    /// buffer and from the re-sliced one, and the intervening-chunk case (the
    /// six retail entries) lands on the body rather than on the chunk.
    #[test]
    fn body_origin_resolves_in_both_buffer_conventions() {
        let body: Vec<u8> = (0..64u8).map(|i| i.wrapping_mul(3) & 0x4F).collect();
        // The intervening chunk must not be the body's own length: the walk
        // recognises the body chunk BY that length, so a collision is
        // ambiguous by construction (no retail carrier has one).
        for mid in [0usize, 0x50] {
            let stream = stream_with(1, &body, mid);
            let whole = legaia_vab::parse(&stream, 4).expect("parse at the VAB");
            let mut out = Vec::new();
            for buf in [stream.clone(), stream[4..].to_vec()] {
                let mut spu = Spu::new();
                let mut alloc = crate::spu::ram::SpuAllocator::new(0x1000, 0x1_0000);
                let bank = VabBank::upload(&mut spu, &mut alloc, &whole, &buf);
                let s = bank.samples[0].expect("the one sample uploaded");
                out.push(spu.ram.slice(s.addr, s.size).to_vec());
            }
            assert_eq!(out[0], body, "mid={mid}: whole-buffer convention");
            assert_eq!(out[1], body, "mid={mid}: re-sliced-at-the-VAB convention");
        }
    }
}
