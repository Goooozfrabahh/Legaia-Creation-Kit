//! Region-keyed random-encounter trigger - port of `FUN_801D9E1C`.
//!
//! This is the faithful overworld / field random-encounter model, distinct
//! from the aggregated weighted-row [`crate::encounter::EncounterTable`]: it
//! preserves the per-region geometry so a moving player rolls against the
//! region it is actually standing in.
//!
//! ## Mechanism (from the disassembly)
//!
//! The reader runs once per movement update:
//!
//! 1. The player's world `(x, z)` is reduced to a **128-unit tile** by an
//!    arithmetic `>> 7` (`worldX >> 7`, `worldZ >> 7`) - region AABBs are in
//!    tile units (`0x801d9e94..0x801d9ec0`).
//! 2. The scene's **condition** table is walked to pick which slice of the
//!    region array is live (`0x801d9f30..0x801d9fd8`). See [`RegionGroup`].
//!    Only that slice is searched next; the rest of the region array belongs
//!    to other story states and is invisible.
//! 3. The selected group is walked **in order**; the first region whose
//!    AABB contains the tile (`x_min <= tx <= x_max && z_min <= tz <= z_max`)
//!    is selected (`0x801d9fe8..0x801da050`).
//! 4. The region's per-step **rate increment** (`region[+4]`) is scaled by the
//!    user encounter-rate setting (`_DAT_8007B5F8`; `0x801da198..0x801da1b4`)
//!    and subtracted from the step counter (`_DAT_8007B5FC`,
//!    `0x801da20c..0x801da21c`). While the counter stays positive, nothing
//!    fires.
//! 5. When the counter drops to `<= 0`, a formation id is rolled uniformly from
//!    the region's `[base, base + count)` slice (`base = region[+6]`,
//!    `count = region[+7]`; `0x801da228..0x801da268`) with a one-step
//!    anti-repeat (if the pick equals the previous formation, advance one and
//!    wrap; `0x801da26c..0x801da290`), then the counter resets to
//!    `0x3ce + (rng_a % 0x1e7) - (rng_b % 0x1e7)` (range `[0x1e8, 0x5b4]`;
//!    `0x801da2dc..0x801da358`).
//!
//! Two RNG draws drive the counter reset and one drives the formation pick;
//! the no-trigger path consumes **zero** RNG (matching retail, which only calls
//! the RNG advance `FUN_80056798` on the trigger branch), so feeding this from
//! the world's shared deterministic RNG keeps replays bit-identical.
//!
//! The accessory / status multiplicative modifiers retail layers on top of the
//! setting scale are ported as [`EncounterRateModifiers`] (`FUN_800431D0`
//! ability bits `0x3B`/`0x3C` and `FUN_8003CE64` system flags `0x1D`/`0x1E`,
//! shifts `<<2`/`>>1`/`<<1`/`>>1` in retail order) and refreshed from the
//! party ability mask + flag bank each step.
//!
//! ## Consumers
//!
//! Both scene modes route this tracker off the scene's MAN encounter section
//! ([`region_encounter_table_from_man`]):
//!
//! - **Overworld** - `legaia_engine_core::world::World::set_world_map_regions`; the per-tile
//!   roll lives in `World::live_world_map_tick`, latching
//!   `World::world_map.pending_encounter`.
//! - **Field** - `legaia_engine_core::world::World::set_field_regions`; the roll lives in
//!   `legaia_engine_core::world::World::on_field_step`, which drives a trigger through the
//!   mean-rate [`crate::encounter::EncounterSession`]'s transition / grace SM via
//!   [`crate::encounter::EncounterSession::trigger_with`]. A field scene whose MAN
//!   has no encounter-region section keeps the aggregated mean-rate session.
//!
//! Source: `ghidra/scripts/funcs/overlay_world_map_walk_801d9e1c.txt` +
//! [`docs/formats/encounter.md`](../../../docs/formats/encounter.md).
//!
//! PORT: FUN_801D9E1C
//! REF: FUN_80056798, FUN_800431D0, FUN_8003CE64

use legaia_scene_formats::man_section;

/// Counter base term (`0x3ce` = 974) - the reset's centre value.
pub const ENCOUNTER_COUNTER_BASE: i32 = 0x3ce;

/// Counter reset modulus (`0x1e7` = 487) applied to each of the two RNG draws.
pub const ENCOUNTER_COUNTER_MOD: u32 = 0x1e7;

/// The encounter step-counter reroll: `r1 % 487 - r2 % 487 + 0x3CE`, a
/// triangular distribution over `488..=1460` centred on 974.
///
/// Retail has this as its own field-overlay leaf, not only inline in the
/// region roll: two `jal 0x80056798` draws, each reduced by the
/// `0x43491159` / `>> 7` reciprocal (the `* 487` rebuild is
/// `((a*16 - a)*4 + a)*8 - a`), then `s0 - (v0 - 0x3CE)`. The FIRST draw is
/// the added term. It has four callers, every one of which stores the result
/// into `_DAT_8007B5FC`: the region roll's trigger reset (inlined here in
/// [`RegionEncounterTracker::on_step`]), field-VM op `4C EC`
/// (`0x801E34F8`), the op-`0x3E` scripted-formation arm (`0x801E076C`), and
/// the scene-entry top-up in the SCUS system-script installer
/// (`0x8003AC90`, see [`encounter_counter_scene_entry_top_up`]).
///
/// `rng` is the retail `rand()` (`0..=0x7FFF`); any non-negative draw gives
/// the same result because the reduction is a truncating signed modulus.
///
/// Whether a player tile change from `prev` to `now` is a **step** the region
/// reader counts.
///
/// `FUN_801D9E1C` caches the player's tile in its own `+0x8E` / `+0x8F`
/// every call (`sb s4,0x8e(s6)` / `sb s3,0x8f(s6)`), then leaves without
/// reading a region unless the new tile is a different one at most one tile
/// away on each axis: `slti v0,v0,0x2` on `|old_x - new_x|` (`0x801D9EF0`)
/// and on `|old_z - new_z|` (`0x801D9F08`), each `beq v0,zero` to the exit.
/// A teleport - a script seating the player across the map, a warp landing -
/// therefore neither drains the step counter nor rolls a fight; the next
/// ordinary step from the landing does. (The `0xFF` cache preset op `0x3E`
/// writes is the reader's other way in; the engine runs that arm itself.)
///
/// REF: FUN_801D9E1C
pub fn is_region_step(prev: (i32, i32), now: (i32, i32)) -> bool {
    prev != now && (prev.0 - now.0).abs() < 2 && (prev.1 - now.1).abs() < 2
}

/// PORT: FUN_801DDF48
pub fn encounter_counter_reroll(mut rng: impl FnMut() -> u32) -> i32 {
    let ra = (rng() % ENCOUNTER_COUNTER_MOD) as i32;
    let rb = (rng() % ENCOUNTER_COUNTER_MOD) as i32;
    ENCOUNTER_COUNTER_BASE + ra - rb
}

/// The scene-entry top-up of the step counter.
///
/// The SCUS system-script installer (`FUN_8003AB2C`, reached once per field
/// scene entry from the MAN decoder `FUN_8003AEB0`) tests
/// `_DAT_8007B5FC < 0x1E7` (`0x8003AC84`); only then does it add half a fresh
/// reroll, rounding toward zero (`srl 31; addu; sra 1` at `0x8003AC98`).
/// A counter at or above 487 is carried across the door unchanged - retail
/// never re-seeds it per scene. Returns the new counter.
///
/// REF: FUN_8003AB2C (the top-up slice at `0x8003AC78..0x8003ACAC`)
pub fn encounter_counter_scene_entry_top_up(counter: i32, rng: impl FnMut() -> u32) -> i32 {
    if counter >= ENCOUNTER_COUNTER_MOD as i32 {
        return counter;
    }
    let r = encounter_counter_reroll(rng);
    // `(r + (r >>> 31)) >> 1` - signed halve toward zero; `r` is always
    // positive here, kept for fidelity.
    counter.wrapping_add(r / 2)
}

/// One scene encounter region: an AABB in 128-unit tiles, a per-step rate
/// increment, and the formation slice it rolls into.
///
/// Mirrors [`man_section::RegionRecord`]'s `+0x00..+0x08` prefix; the region's
/// `y` AABB fields are tested against the player's **Z** tile (`worldZ >> 7`),
/// matching the disassembly's `s3` register.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct EncounterRegion {
    pub tile_x_min: u8,
    pub tile_z_min: u8,
    pub tile_x_max: u8,
    pub tile_z_max: u8,
    /// Per-step rate increment (`region[+4]`).
    pub rate_increment: u8,
    /// First formation index this region rolls into (`region[+6]`).
    pub formation_base: u8,
    /// Number of formations in the roll range (`region[+7]`).
    pub formation_count: u8,
    /// The bytes the reader's battle-setup half takes from the same record
    /// ([`region_battle_setup`]).
    pub setup: RegionSetupBytes,
}

/// The region-record bytes past the roll fields that `FUN_801D9E1C`'s
/// battle-setup half reads (`0x801DA058..0x801DA12C`).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub struct RegionSetupBytes {
    /// `region[+5]`, the high byte of the halfword the rate is the low byte
    /// of (`FUN_8003CE9C(region + 4)`); its low seven bits are the high byte
    /// of the world-map return word.
    pub byte5: u8,
    /// `region[+8]`. Read on every layout (`lbu v0, 8(s2)` at `0x801DA064`,
    /// before the stride test) - on an 8-byte record it is the **next**
    /// record's first byte, which is what the decoder stores then too.
    pub byte8: u8,
    /// `region[+9..+0xC]`, read only when the region stride `ctrl[+0x5F]`
    /// is at least `0xC` (`sltiu v0, v0, 0xc` at `0x801DA090`).
    pub ext: Option<[u8; 3]>,
}

/// Where the travel art puts the party back on the world map: the triple
/// `0x80084628` (map word) / `0x80084624` (tile X) / `0x8008462C` (tile Z)
/// the world-map panel's resolve scan compares against
/// (`legaia_engine_field::world_map_panel_host::VisitedMap`). A region record on the
/// long layout writes it; so do the Door of Wind commit and a field-VM arm.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct WorldMapReturn {
    /// `region[+9] | (region[+5] & 0x7F) << 8`.
    pub map_word: u16,
    /// `region[+0xA]`.
    pub tile_x: u8,
    /// `region[+0xB]`.
    pub tile_z: u8,
}

/// What the battle-setup half of `FUN_801D9E1C` stores when the player's
/// tile lands in a region - on every step of the random-roll path
/// (`a1 = 1`) and on the op-`0x3E` scripted-battle install (`a1 = 0`,
/// `0x801E0710`), before either path's roll or battle request.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RegionBattleSetup {
    /// `_DAT_8007BD60 = region[+8] & 0x1F` (`0x801DA064..0x801DA070`): the
    /// battle-stage variant. Battle init `FUN_800513F0` loads the backdrop
    /// from PROT entry `scene_index + variant` through `FUN_8001FA88`
    /// (`0x80051A0C..0x80051A3C`), `scene_index` being the CDNAME index word
    /// `0x80084540` - see [`legaia_scene_formats::battle_backdrop::battle_stage_entry_for_variant`].
    pub stage_variant: u8,
    /// `_DAT_8007B64B = (region[+8] >> 5) & 1` (`0x801DA09C..0x801DA0AC`):
    /// battle init keeps the backdrop shell's object 1 when set
    /// (`legaia_scene_formats::battle_backdrop`). `None` on the short layout, which
    /// leaves the byte alone.
    pub keep_backdrop_object_1: Option<bool>,
    /// Scratchpad `0x1F800394 & 0x100000` after the half: raised on every
    /// hit (`lui a0, 0x30; or` at `0x801DA068..0x801DA084`) and dropped on
    /// the long layout when `region[+8] & 0x80`. The item list dims the Door
    /// of Light row while it is set (`0x8003093C..0x8003094C`).
    pub door_of_light_blocked: bool,
    /// The same for bit `0x200000` (dropped by `region[+8] & 0x40`) and the
    /// Door of Wind row (`0x80030958..0x80030970`).
    pub door_of_wind_blocked: bool,
    /// The world-map return triple, long layout only.
    pub world_map_return: Option<WorldMapReturn>,
}

/// The battle-setup half of the region reader: `FUN_801D9E1C` at
/// `0x801DA058..0x801DA12C`, the part that runs whether or not the call rolls
/// (`a1`, tested at `0x801DA16C` after it).
///
/// PORT: FUN_801D9E1C (the region battle-setup half, `0x801DA058..0x801DA12C`)
pub fn region_battle_setup(bytes: &RegionSetupBytes) -> RegionBattleSetup {
    let b8 = bytes.byte8;
    let mut setup = RegionBattleSetup {
        stage_variant: b8 & 0x1F,
        keep_backdrop_object_1: None,
        door_of_light_blocked: true,
        door_of_wind_blocked: true,
        world_map_return: None,
    };
    if let Some([b9, ba, bb]) = bytes.ext {
        setup.keep_backdrop_object_1 = Some((b8 >> 5) & 1 != 0);
        if b8 & 0x80 != 0 {
            setup.door_of_light_blocked = false;
        }
        if b8 & 0x40 != 0 {
            setup.door_of_wind_blocked = false;
        }
        setup.world_map_return = Some(WorldMapReturn {
            map_word: u16::from(b9) | (u16::from(bytes.byte5 & 0x7F) << 8),
            tile_x: ba,
            tile_z: bb,
        });
    }
    setup
}

impl EncounterRegion {
    /// `true` if the 128-unit tile `(tile_x, tile_z)` is inside this region's
    /// AABB. Tiles are signed (`worldX >> 7` can be negative on the overworld);
    /// the bounds are unsigned bytes, so the comparison widens to `i32` exactly
    /// as the retail `slt` does against the byte-loaded bounds.
    pub fn contains_tile(&self, tile_x: i32, tile_z: i32) -> bool {
        tile_x >= self.tile_x_min as i32
            && tile_x <= self.tile_x_max as i32
            && tile_z >= self.tile_z_min as i32
            && tile_z <= self.tile_z_max as i32
    }
}

/// User encounter-rate setting (`_DAT_8007B5F8`; the world-map debug `ENCOUNT`
/// row cycles it `0 -> 1 -> 2 -> 3 -> 0`). The numeric value is the retail
/// global; [`Self::scale`] ports the exact per-setting arithmetic.
///
/// The variants are named for what each value *does*, which is not the order
/// a reader expects. `1` is the plain pass-through, and it is the value three
/// independent retail save states carry - so `1`, not `2`, is the rate a
/// retail playthrough runs at. `2` quadruples it and `3` quarters it. The
/// only writer in the static corpus is the debug menu's `ENCOUNT` row, which
/// cycles the byte; the boot value comes from outside that corpus and the
/// captures are what pin it.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum EncounterRateSetting {
    /// `0` - encounters off. Retail does not merely zero the increment: the
    /// entity SM's state-0 arm tests this byte and skips the call to the roll
    /// entirely (`FUN_801DA51C` `0x801da59c..0x801da5b0`).
    Off,
    /// `1` - rate increment used as-is. The retail runtime value.
    #[default]
    Normal,
    /// `2` - rate increment `<< 2` (four times as many encounters).
    High,
    /// `3` - rate increment `>> 2` (a quarter as many).
    Low,
}

impl EncounterRateSetting {
    /// The retail global value (`_DAT_8007B5F8`).
    pub fn as_u8(self) -> u8 {
        match self {
            Self::Off => 0,
            Self::Normal => 1,
            Self::High => 2,
            Self::Low => 3,
        }
    }

    /// Build from the retail global value; out-of-range falls back to
    /// [`Self::Normal`].
    pub fn from_u8(v: u8) -> Self {
        match v {
            0 => Self::Off,
            2 => Self::High,
            3 => Self::Low,
            _ => Self::Normal,
        }
    }

    /// Scale a region's per-step rate increment, porting
    /// `0x801da198..0x801da1b4`: the byte is compared against `2` (shift left
    /// 2) and against `3` (shift right 2), and every other value - `1`
    /// included - leaves the increment alone. `Off` zeroes it so the counter
    /// never advances, standing in for retail's skip of the whole roll.
    pub fn scale(self, increment: u8) -> u32 {
        let inc = increment as u32;
        match self {
            Self::Off => 0,
            Self::Normal => inc,
            Self::High => inc << 2,
            Self::Low => inc >> 2,
        }
    }
}

/// Accessory / status encounter-rate modifiers, applied to the setting-scaled
/// per-step rate increment in retail order (`FUN_801D9E1C`
/// `0x801da1b8..0x801da200` - four sequential shifts on the same value):
///
/// | Source | Retail test | Effect |
/// |---|---|---|
/// | High Encounter passive (Bad Luck Bell / Nemesis Gem) | `FUN_800431D0(0x3B)` | `<< 2` |
/// | Low Encounter passive (Good Luck Bell / Evil Talisman) | `FUN_800431D0(0x3C)` | `>> 1` |
/// | System flag `0x1D` | `FUN_8003CE64(0x1D)` | `<< 1` |
/// | System flag `0x1E` | `FUN_8003CE64(0x1E)` | `>> 1` |
///
/// The magnitudes are statically pinned in `overlay_world_map_801d9e1c.txt`
/// (no capture needed). The engine refreshes these from the party ability
/// mask + system-flag bank each step
/// (`legaia_engine_core::world::World::encounter_rate_modifiers`).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct EncounterRateModifiers {
    /// Ability bit `0x3B` set on any member - rate `<< 2`.
    pub high_encounter: bool,
    /// Ability bit `0x3C` set on any member - rate `>> 1`.
    pub low_encounter: bool,
    /// System flag `0x1D` set - rate `<< 1`.
    pub flag_high: bool,
    /// System flag `0x1E` set - rate `>> 1`.
    pub flag_low: bool,
}

impl EncounterRateModifiers {
    /// Apply the four shifts in retail order to a setting-scaled rate.
    // PORT: FUN_801D9E1C (accessory/status rate shifts, 0x801da1b8..0x801da200)
    pub fn apply(self, rate: u32) -> u32 {
        let mut r = rate;
        if self.high_encounter {
            r <<= 2;
        }
        if self.low_encounter {
            r >>= 1;
        }
        if self.flag_high {
            r <<= 1;
        }
        if self.flag_low {
            r >>= 1;
        }
        r
    }

    /// `true` when no modifier is active (the default state).
    pub fn is_neutral(self) -> bool {
        self == Self::default()
    }
}

/// One story-flag-gated slice of a scene's region array.
///
/// A scene's regions are not one list - they are several **variants of the
/// same scene**, one per story state, laid end to end, and the MAN's
/// condition array says where each starts. `FUN_801D9E1C` walks the
/// conditions in order and takes the first whose flag is set (or the
/// `0xFFFF` unconditional tail); the regions of every other group are
/// unreachable in that state.
///
/// Reading the array flat instead is what makes most scenes look
/// encounter-free: a group's rows commonly begin with (or consist of) a
/// whole-map `rate 0` row, and a flat first-match lookup stops there.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RegionGroup {
    /// Story flag gating this group, or [`DEFAULT_GROUP_FLAG`] for the
    /// unconditional tail every retail scene ends with.
    pub flag_id: u16,
    /// Index of the group's first region in [`RegionEncounterTable::regions`].
    pub start: usize,
    /// Number of regions in the group.
    pub len: usize,
}

/// The condition flag id that means "no flag test - this group always wins"
/// (`FUN_801D9E1C` `0x801d9f50`).
pub const DEFAULT_GROUP_FLAG: u16 = legaia_scene_formats::man_section::CONDITION_DEFAULT_FLAG;

/// Per-scene region-keyed encounter table.
///
/// `regions` holds every authored region across every story variant;
/// `groups` says which slice belongs to which story flag, and `active` is
/// the slice the roll currently searches. Refresh `active` from the live
/// flag bank with [`Self::select_group`] before each step - retail
/// re-evaluates the condition walk every step, so a flag set mid-scene
/// changes the region set immediately.
#[derive(Clone, Debug, Default)]
pub struct RegionEncounterTable {
    pub scene_label: String,
    pub regions: Vec<EncounterRegion>,
    /// The condition partition. Empty for hand-built (synthetic) tables,
    /// which behave as one implicit group covering every region.
    pub groups: Vec<RegionGroup>,
    /// Currently selected `(start, len)` slice of `regions`. `None` means
    /// the condition walk found no group - retail's "return without
    /// rolling" exit, which is emphatically not the same as "search
    /// everything".
    active: Option<(usize, usize)>,
}

impl RegionEncounterTable {
    pub fn new(scene_label: impl Into<String>) -> Self {
        Self {
            scene_label: scene_label.into(),
            regions: Vec::new(),
            groups: Vec::new(),
            active: None,
        }
    }

    /// Re-run the condition walk against the live story-flag bank and latch
    /// the group it selects.
    ///
    /// `flag_test(flag_id)` answers the `FUN_8003CE64` question. A table with
    /// no `groups` (a synthetic one) keeps every region active.
    // PORT: FUN_801D9E1C (condition walk, 0x801d9f30..0x801d9fd8)
    pub fn select_group(&mut self, mut flag_test: impl FnMut(u16) -> bool) {
        if self.groups.is_empty() {
            self.active = Some((0, self.regions.len()));
            return;
        }
        self.active = self
            .groups
            .iter()
            .find(|g| g.flag_id == DEFAULT_GROUP_FLAG || flag_test(g.flag_id))
            .map(|g| (g.start, g.len));
    }

    /// The region slice the roll currently searches (see [`Self::select_group`]).
    pub fn active_regions(&self) -> &[EncounterRegion] {
        match self.active {
            Some((start, len)) => {
                let end = start.saturating_add(len).min(self.regions.len());
                let start = start.min(end);
                &self.regions[start..end]
            }
            // A table built by hand (tests, synthetic worlds) never had a
            // condition walk run over it; treat it as all-active rather than
            // silently dead.
            None if self.groups.is_empty() => &self.regions,
            None => &[],
        }
    }

    /// The selected group's descriptor, when the table carries a condition
    /// partition and the walk matched one.
    pub fn active_group(&self) -> Option<RegionGroup> {
        let (start, len) = self.active?;
        self.groups
            .iter()
            .copied()
            .find(|g| g.start == start && g.len == len)
    }

    /// Reduce a world coordinate to its 128-unit tile (`coord >> 7`,
    /// arithmetic so negatives floor toward `-inf`, matching the retail
    /// `sra ...,0x17` on the sign-extended halfword).
    pub fn world_to_tile(coord: i16) -> i32 {
        (coord as i32) >> 7
    }

    /// The first region **of the active group** whose AABB contains tile
    /// `(tile_x, tile_z)`, or `None` when the player stands outside every one
    /// of them (the retail walk that runs off the end without a hit).
    pub fn region_at_tile(&self, tile_x: i32, tile_z: i32) -> Option<&EncounterRegion> {
        self.active_regions()
            .iter()
            .find(|r| r.contains_tile(tile_x, tile_z))
    }

    /// [`Self::region_at_tile`] from a world `(x, z)`.
    pub fn region_at_world(&self, world_x: i16, world_z: i16) -> Option<&EncounterRegion> {
        self.region_at_tile(Self::world_to_tile(world_x), Self::world_to_tile(world_z))
    }

    pub fn is_empty(&self) -> bool {
        self.regions.is_empty()
    }

    /// `true` when at least one region **of the active group** that can
    /// actually produce a battle (non-zero rate increment **and** a non-empty
    /// formation range) owns at least one tile it is the *first* match for.
    ///
    /// Two qualifiers, both load-bearing:
    ///
    /// - *Active group*: rollability is a property of the (scene, story
    ///   state) pair, not of the scene. A town is silent until its "under
    ///   attack" flag flips the region set; a dungeon can be silent before
    ///   the story opens it. Call [`Self::select_group`] first.
    /// - *First match*: [`Self::region_at_tile`] stops at the first containing
    ///   region, exactly like retail's walk, so a rollable region whose every
    ///   tile is already covered by an earlier rate-0 row in the same group is
    ///   unreachable - the scan below shadows regions in group order the same
    ///   way the lookup does. Groups routinely end with a whole-map rate-0
    ///   catch-all, which is the "outside every named region, roll nothing"
    ///   row and correctly shadows nothing before it.
    ///
    /// Cost is one pass over the union of the group's region AABBs against a
    /// 256x256 claim map, so call it on scene entry (or cache it), not per
    /// frame.
    pub fn any_rollable(&self) -> bool {
        let mut claimed = vec![false; 256 * 256];
        for r in self.active_regions() {
            let mut owns_a_tile = false;
            for tz in r.tile_z_min..=r.tile_z_max {
                for tx in r.tile_x_min..=r.tile_x_max {
                    let idx = tz as usize * 256 + tx as usize;
                    if !claimed[idx] {
                        claimed[idx] = true;
                        owns_a_tile = true;
                    }
                }
            }
            if owns_a_tile && r.rate_increment > 0 && r.formation_count > 0 {
                return true;
            }
        }
        false
    }
}

/// Build a [`RegionEncounterTable`] from a scene's decoded MAN bytes.
///
/// Returns `None` when the MAN header / encounter section fails to parse or the
/// section declares no regions. Companion to
/// [`crate::encounter_man::encounter_table_from_man`] (which aggregates the
/// same regions into a single weighted table); this one keeps the geometry so a
/// position-routed engine can roll against the active region.
///
/// Every region variant the scene authors is kept, and the condition array is
/// carried alongside as [`RegionEncounterTable::groups`]. The table is left
/// resolved for the **all-flags-clear** state; a host with a live flag bank
/// should call [`RegionEncounterTable::select_group`] (or
/// [`RegionEncounterTracker::select_group`]) per step.
pub fn region_encounter_table_from_man(
    scene_label: &str,
    man_bytes: &[u8],
) -> Option<RegionEncounterTable> {
    let man = man_section::parse(man_bytes).ok()?;
    let body = man.encounter_section_body(man_bytes)?;
    let es = man_section::parse_encounter_section(body).ok()?;

    let mut table = RegionEncounterTable::new(scene_label);
    let stride = usize::from(es.region_stride);
    let array = body.get(es.region_range.0..).unwrap_or(&[]);
    for (i, region) in man_section::region_records(body, &es).enumerate() {
        let Some(region) = region else {
            continue;
        };
        let raw = |k: usize| array.get(i * stride + k).copied();
        table.regions.push(EncounterRegion {
            tile_x_min: region.aabb_x_min,
            tile_z_min: region.aabb_y_min,
            tile_x_max: region.aabb_x_max,
            tile_z_max: region.aabb_y_max,
            rate_increment: region.rate_increment,
            formation_base: region.formation_range_base,
            formation_count: region.formation_range_count,
            setup: RegionSetupBytes {
                byte5: region.reserved_5,
                byte8: raw(8).unwrap_or(0),
                ext: (stride >= 0xC)
                    .then(|| Some([raw(9)?, raw(10)?, raw(11)?]))
                    .flatten(),
            },
        });
    }

    if table.regions.is_empty() {
        return None;
    }

    let mut start = 0usize;
    for cond in man_section::condition_records(body, &es).flatten() {
        let len = cond.region_count as usize;
        table.groups.push(RegionGroup {
            flag_id: cond.flag_id,
            start,
            len,
        });
        start = start.saturating_add(len);
    }
    // Resolve for a cleared flag bank so a host that never refreshes still
    // gets the unconditional tail rather than group 0.
    table.select_group(|_| false);
    Some(table)
}

/// A successful region-encounter roll.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RegionEncounterRoll {
    /// Picked formation index (a row in the scene's formation list).
    pub formation_id: u8,
}

/// Per-scene region-keyed encounter state (the `FUN_801D9E1C` step counter +
/// anti-repeat latch).
#[derive(Clone, Debug)]
pub struct RegionEncounterTracker {
    table: RegionEncounterTable,
    /// `_DAT_8007B5FC` - the step counter; a trigger fires when it reaches
    /// `<= 0`. Seeded to [`ENCOUNTER_COUNTER_BASE`] so the first encounter
    /// takes a believable number of steps even before the first reset.
    counter: i32,
    /// `_DAT_8007B5F8` user setting.
    setting: EncounterRateSetting,
    /// `_DAT_8007B605` - the previous formation id, for the one-step
    /// anti-repeat. `None` until the first trigger.
    last_formation: Option<u8>,
    /// Master suppression (post-battle grace / cutscene). When set, steps never
    /// advance the counter.
    suppressed: bool,
    /// Accessory / status rate modifiers, refreshed by the host each step.
    modifiers: EncounterRateModifiers,
}

impl RegionEncounterTracker {
    pub fn new(table: RegionEncounterTable) -> Self {
        Self {
            table,
            counter: ENCOUNTER_COUNTER_BASE,
            setting: EncounterRateSetting::default(),
            last_formation: None,
            suppressed: false,
            modifiers: EncounterRateModifiers::default(),
        }
    }

    pub fn table(&self) -> &RegionEncounterTable {
        &self.table
    }

    /// Re-run the scene's condition walk against the live story-flag bank.
    ///
    /// Retail evaluates this every step, so hosts refresh it alongside
    /// [`Self::set_modifiers`]: a flag set mid-scene swaps the region set
    /// (and therefore the rates, formations and battle backdrop) on the very
    /// next step.
    pub fn select_group(&mut self, flag_test: impl FnMut(u16) -> bool) {
        self.table.select_group(flag_test);
    }

    pub fn setting(&self) -> EncounterRateSetting {
        self.setting
    }

    pub fn set_setting(&mut self, setting: EncounterRateSetting) {
        self.setting = setting;
    }

    pub fn modifiers(&self) -> EncounterRateModifiers {
        self.modifiers
    }

    /// Install the current accessory / status rate modifiers (see
    /// [`EncounterRateModifiers`]); the host refreshes these before each
    /// step roll.
    pub fn set_modifiers(&mut self, modifiers: EncounterRateModifiers) {
        self.modifiers = modifiers;
    }

    pub fn suppress(&mut self) {
        self.suppressed = true;
    }

    pub fn clear_suppression(&mut self) {
        self.suppressed = false;
    }

    pub fn is_suppressed(&self) -> bool {
        self.suppressed
    }

    pub fn counter(&self) -> i32 {
        self.counter
    }

    /// Overwrite the step counter (`_DAT_8007B5FC`). The counter is one retail
    /// global shared by every scene, so the world seeds a freshly installed
    /// tracker from its carried value and the non-roll writers (op `4C EC`,
    /// the op-`0x3E` formation arm, the scene-entry top-up) land here.
    pub fn set_counter(&mut self, counter: i32) {
        self.counter = counter;
    }

    /// Reset per-scene state (scene change). Re-seeds the counter and clears
    /// the anti-repeat latch.
    pub fn reset(&mut self) {
        self.counter = ENCOUNTER_COUNTER_BASE;
        self.last_formation = None;
        self.suppressed = false;
    }

    /// Advance one movement step at world `(world_x, world_z)`.
    ///
    /// `rng` is pulled only on the trigger branch (formation pick + the two
    /// counter-reset draws), so a non-triggering step consumes no RNG - the
    /// same property the retail roll has. Returns `Some` when a battle should
    /// start.
    pub fn on_step(
        &mut self,
        world_x: i16,
        world_z: i16,
        mut rng: impl FnMut() -> u32,
    ) -> Option<RegionEncounterRoll> {
        if self.suppressed || self.setting == EncounterRateSetting::Off {
            return None;
        }
        let region = *self.table.region_at_world(world_x, world_z)?;
        if region.formation_count == 0 {
            return None;
        }
        let inc = self
            .modifiers
            .apply(self.setting.scale(region.rate_increment)) as i32;
        // While the counter stays positive, the step does not fire and no RNG
        // is consumed (retail `bgtz v1, ...; sw v1, _DAT_8007B5FC`).
        if self.counter - inc > 0 {
            self.counter -= inc;
            return None;
        }

        // Trigger: pick a formation uniformly from the region's slice, with the
        // one-step anti-repeat.
        let count = region.formation_count;
        let pick = (rng() % count as u32) as u8;
        let mut formation_id = region.formation_base.wrapping_add(pick);
        if Some(formation_id) == self.last_formation {
            // Advance one and wrap to base at the slice end.
            let end = region.formation_base.wrapping_add(count);
            formation_id = formation_id.wrapping_add(1);
            if formation_id == end {
                formation_id = region.formation_base;
            }
        }
        self.last_formation = Some(formation_id);

        // Counter reset: 0x3ce + (rng_a % 0x1e7) - (rng_b % 0x1e7).
        self.counter = encounter_counter_reroll(&mut rng);

        Some(RegionEncounterRoll { formation_id })
    }
}

#[cfg(test)]
mod tests;
