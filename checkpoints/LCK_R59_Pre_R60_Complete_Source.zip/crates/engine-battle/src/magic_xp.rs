//! Summon-magic spell XP: the per-spell experience that levels Seru magic.
//!
//! Casting Seru magic trains the spell itself. The character record keeps a
//! per-spell-slot u32 XP array at `+0x8` (parallel to the spell-id list at
//! `+0x13D` and the level bytes at `+0x161`); the battle damage finisher
//! accrues into it (`FUN_801ddb30` tail, ported as
//! [`legaia_engine_battle_vm::battle_formulas::summon_spell_xp_gain`]) and the
//! post-summon check `FUN_801e70bc` levels the spell up against the static
//! `SCUS_942.54` threshold table at `0x8007656C` (ported as
//! [`legaia_engine_battle_vm::battle_formulas::summon_magic_levels_up`]).
//!
//! This module owns the data plumbing both kernels need:
//!
//! - [`thresholds_from_scus`] decodes the threshold table off the user's
//!   `SCUS_942.54` (no Sony bytes committed - same pattern as
//!   `legaia_engine_menus::shop_catalog::ShopItemData::from_scus`);
//! - the record accessors read/write the `+0x8` XP array through
//!   [`legaia_save::CharacterRecord::raw`], so the accrued XP round-trips
//!   through saves for free.
//!
//! The live wiring is `World::cast_spell_on_slots` (accrual + level-up after
//! a party summon cast) - the leveled `+0x161` byte is exactly what the next
//! cast's magic-power stage reads (`caster_magic_power_byte`), closing the
//! cast → XP → level → stronger-cast loop.
//!
//! REF: FUN_801ddb30, FUN_801e70bc

use legaia_save::CharacterRecord;

/// RAM address of the magic-XP threshold table in `SCUS_942.54`
/// (`overlay_battle_action_801e70bc.txt`: `*(ushort *)((level - 1) * 2 +
/// -0x7ff89a94)` = `0x8007656C + (level - 1) * 2`).
pub const THRESHOLDS_VA: u32 = 0x8007_656C;

/// Number of threshold steps: levels 1..=8 each have an entry; level 9 is
/// the cap (`FUN_801e70bc` guards `level < 9` before the increment).
pub const THRESHOLD_STEPS: usize = 8;

/// Character-record offset of the per-spell-slot u32 XP array
/// (`overlay_battle_action_801ddb30.txt:1059`: `slot * 4 + record -
/// 0x7ff7b8f0` = live `0x80084710` = record base `0x80084708` + `0x8`).
pub const SPELL_XP_OFFSET: usize = 0x8;

/// Retail search bound over the spell-id list: both `FUN_801ddb30` and
/// `FUN_801e70bc` scan at most `0x20` entries of the `+0x13D` array (the
/// same bound the magic-power stage uses).
pub const SPELL_SEARCH_BOUND: usize = 0x20;

/// Decode the magic-XP threshold table from `SCUS_942.54` bytes.
///
/// Reads [`THRESHOLD_STEPS`] little-endian u16s at [`THRESHOLDS_VA`] through
/// the PS-X EXE header's `t_addr` (file offset `va - t_addr + 0x800`).
/// Returns `None` when the bytes aren't a PS-X EXE, the address falls outside
/// the text segment, or the table fails its integrity shape (strictly
/// ascending, all non-zero - the retail table is `17, 50, 92, … 536`).
pub fn thresholds_from_scus(scus: &[u8]) -> Option<[u16; THRESHOLD_STEPS]> {
    if scus.len() < 0x800 || &scus[0..8] != b"PS-X EXE" {
        return None;
    }
    let t_addr = u32::from_le_bytes(scus[0x18..0x1C].try_into().ok()?);
    let t_size = u32::from_le_bytes(scus[0x1C..0x20].try_into().ok()?);
    if THRESHOLDS_VA < t_addr
        || THRESHOLDS_VA + (THRESHOLD_STEPS * 2) as u32 > t_addr.checked_add(t_size)?
    {
        return None;
    }
    let off = (THRESHOLDS_VA - t_addr) as usize + 0x800;
    let bytes = scus.get(off..off + THRESHOLD_STEPS * 2)?;
    let mut out = [0u16; THRESHOLD_STEPS];
    for (i, slot) in out.iter_mut().enumerate() {
        *slot = u16::from_le_bytes([bytes[i * 2], bytes[i * 2 + 1]]);
    }
    // Integrity: a level-up curve is strictly ascending and starts non-zero.
    if out[0] == 0 || out.windows(2).any(|w| w[0] >= w[1]) {
        return None;
    }
    Some(out)
}

/// Index of `spell_id` in the record's spell-id list (`+0x13D`), scanning at
/// most [`SPELL_SEARCH_BOUND`] entries - the shared lookup both retail
/// functions open with. `None` when the spell isn't in the list (retail would
/// fall through with slot `0x20` and touch bytes past the arrays; the engine
/// skips instead).
pub fn spell_slot(record: &CharacterRecord, spell_id: u8) -> Option<usize> {
    let list = record.spell_list();
    list.ids
        .iter()
        .take(SPELL_SEARCH_BOUND)
        .position(|&id| id == spell_id)
}

/// Accrued XP for the spell at `slot` - the u32 at record `+0x8 + slot * 4`.
pub fn spell_xp(record: &CharacterRecord, slot: usize) -> u32 {
    let off = SPELL_XP_OFFSET + slot * 4;
    legaia_bytes::u32_le(&record.raw, off).unwrap_or(0)
}

/// Add `gain` (saturating) to the spell-XP slot. No-op when the offset is out
/// of range (slot >= [`SPELL_SEARCH_BOUND`] never happens via [`spell_slot`]).
pub fn add_spell_xp(record: &mut CharacterRecord, slot: usize, gain: u32) {
    let off = SPELL_XP_OFFSET + slot * 4;
    if record.raw.len() < off + 4 {
        return;
    }
    let cur = spell_xp(record, slot);
    record.raw[off..off + 4].copy_from_slice(&cur.saturating_add(gain).to_le_bytes());
}

/// PORT: FUN_801E92DC - learn a new Seru spell by **prepending** it to the
/// character's spell list. Retail shifts the three parallel arrays up by one
/// slot in a single descending loop (`id[i+1] = id[i]`, `level[i+1] =
/// level[i]`, `xp[i+1] = xp[i]` for `i = count-1..=0`), then writes slot 0's
/// id, `level = 1`, `xp = 0`, and increments the count. The newest Seru
/// therefore always lists first. (The randomizer's shiny-Seru feature
/// patches exactly this routine's level write + shift - see
/// `crates/code-hooks/src/shiny_seru/`.)
///
/// ## The stored id is the FULL spell id, not its low byte
///
/// Retail's parameter is the id **minus** `0x80` and the store re-adds it:
/// `801e93a8 addiu v1,t3,0x80` / `801e93ac sb v1,0x705(v0)`, where `t3` is
/// the incoming argument. So the `+0x13D` array holds the full `0x8x` id -
/// which is also what the level-up check compares it against: `801e7124 lbu
/// v1,0x1df(a0)` (the actor's action id) against `801e7128 lbu v0,0x705(v0)`
/// (the array entry), and `801e7150 addiu v1,v0,-0x86` puts that action id in
/// the `0x86..` band. This port therefore takes the id the array stores and
/// writes it unchanged; the `- 0x80` an earlier reading applied stored
/// retail's *argument* instead of its *result*, which would have broken the
/// [`spell_slot`] lookup that scans the same array by full id.
///
/// The shift is bounded to the record's array capacity
/// ([`legaia_save::MAX_SPELLS`]); retail's unbounded `do`/`while` never
/// exceeds it in practice (the id space `0x81..=0x8B` caps a legitimate list
/// at 11 entries).
///
/// Driven from `World::resolve_captures`: every accepted capture whose
/// points crossed a Seru's learn threshold commits the learn into the
/// character record here, beside the `SeruCaptureLog::learned_spells` read
/// model the menus and the battle spell session list from.
pub fn learn_spell_prepend(record: &mut CharacterRecord, spell_id: u8) {
    let mut list = record.spell_list();
    let count = (list.count as usize).min(list.ids.len() - 1);
    // Shift ids/levels (descending, like retail's single loop) ...
    for i in (0..count).rev() {
        list.ids[i + 1] = list.ids[i];
        list.levels[i + 1] = list.levels[i];
    }
    list.ids[0] = spell_id;
    list.levels[0] = 1;
    list.count = list.count.wrapping_add(1);
    record.set_spell_list(list);
    // ... and the parallel u32 XP array at +0x8.
    for i in (0..count).rev() {
        let xp = spell_xp(record, i);
        let off = SPELL_XP_OFFSET + (i + 1) * 4;
        record.raw[off..off + 4].copy_from_slice(&xp.to_le_bytes());
    }
    record.raw[SPELL_XP_OFFSET..SPELL_XP_OFFSET + 4].copy_from_slice(&0u32.to_le_bytes());
}

// ---------------------------------------------------------------------------
// Menu-cast (pause-menu Magic screen) leveling arm - FUN_800402F4
// ---------------------------------------------------------------------------
//
// The pause menu's two magic-cast sub-screens (`FUN_801D9280` all-targets,
// `FUN_801D9594` single target) apply their heal through the shared
// effect-apply handler `FUN_800402F4`, whose HP-heal arms carry an inline
// copy of the same accrue-then-threshold-test loop the battle summon path
// runs (`ghidra/scripts/funcs/800402f4.txt`):
//
// - the accrual target is the SAME per-spell u32 XP array: the store is
//   `sw v1, 0x5D0(0x80084140 + char*0x414 + slot*4)`, and `0x80084140 +
//   0x5C8 = 0x80084708` (the record base), so `+0x5D0` off the save-context
//   window is exactly [`SPELL_XP_OFFSET`] (`+0x8`) off the record - one
//   accumulator, not two;
// - the gain is a flat per-cast grant (see [`menu_heal_xp_gain`]), not the
//   battle path's damage-proportional one;
// - the threshold test runs only outside battle (`_DAT_8007B83C != 0x15`):
//   level byte `+0x729` (= record `+0x161 + slot`) gated `< 9`, raw u16
//   table entry `0x8007656C[level-1]` strictly less than the accumulator,
//   then `level += 1` and the notification setter `FUN_80035C00(char, slot)`
//   fires - the `(_DAT_8007BB70, _DAT_8007BB78)` pair window 7 reads.

/// Battle heal-module spell-XP grant for one healed seat.
///
/// The three player Seru heals bump the caster's per-spell XP word in their
/// own tick arm - `lw v0,0x5d0(v1)` / `addiu` / `sw v0,0x5d0(v1)` off
/// `0x80084140 + char * 0x414 + slot * 4`, i.e. this module's XP array at
/// record `+0x8` - choosing between two grants by whether the seat's missing
/// HP covered the module's full amount. A seat missing nothing credits
/// nothing (the `beq a3,zero` skip). Unlike the damage tail there is no
/// group / single split:
///
/// | Module | full | clamped | sites |
/// |---|---|---|---|
/// | Vera `0x83` (signed `slt`) | `+0xC` | `+0x4` | `0x801F7CCC` / `0x801F7CA4` |
/// | Orb `0x89` | `+0x4` | `+0x2` | `0x801F7B50` / `0x801F7B2C` |
/// | Spoon `0x91` | `+0x4` | `+0x2` | `0x801F80D4` / `0x801F80B0` |
///
/// The full amounts are `vera_heal_amount` / `orb_heal_amount` /
/// `spoon_heal_amount` of `magic_level`. Each arm gates the bump on the
/// special-battle word `0x8007BAC0` being zero; that gate is applied where
/// the gain banks (`World::accrue_summon_spell_xp`). Any other id returns 0.
///
/// REF: FUN_801F69D8 (PROT 0905 / 0911 / 0919 heal arms)
pub fn module_heal_xp_gain(spell_id: u8, magic_level: u8, hp: u16, max_hp: u16) -> u32 {
    use legaia_engine_battle_vm::battle_formulas as f;
    let missing = i32::from(max_hp) - i32::from(hp);
    let (want, full, clamped) = match spell_id {
        0x83 => (
            (u32::from(magic_level) * f::VERA_HEAL_PER_LEVEL + f::VERA_HEAL_BASE) as i32,
            0xC,
            0x4,
        ),
        0x89 => (f::orb_heal_amount(magic_level) as i32, 0x4, 0x2),
        0x91 => (f::spoon_heal_amount(magic_level) as i32, 0x4, 0x2),
        _ => return 0,
    };
    if missing <= 0 {
        0
    } else if missing < want {
        clamped
    } else {
        full
    }
}

/// Horn (`0x9C`, PROT 0930) spell-XP grant for one party seat.
///
/// Horn strikes nothing - it never calls `FUN_801DD0AC`, so the finisher's
/// slot-7 tail never runs for it - and credits the caster's XP word in its
/// own restore arm instead. The arm walks **every** party seat
/// (`0 .. *(ctx)+0`, `0x801F786C..0x801F7B1C`), refills the seat to its max
/// HP, clears its status word `+0x16E`, and bumps the XP word twice:
/// `+3` when the seat was missing HP (`beq a2,zero` at `0x801F7978`, add at
/// `0x801F79A0`) and `+1` when its status word was non-zero (`beq v0,zero` at
/// `0x801F79B8`, add at `0x801F7A14`). Both bumps sit behind the special-battle
/// word `0x8007BAC0`, which the engine applies where the gain banks.
///
/// REF: FUN_801F6A74 (PROT 0930 restore arm)
pub fn horn_seat_xp_gain(hp: u16, max_hp: u16, status_word_nonzero: bool) -> u32 {
    let missing = u32::from(max_hp != hp);
    3 * missing + u32::from(status_word_nonzero)
}

/// Jedo (`0x9D`, PROT 0931) spell XP per living monster seat in a fight that
/// is **not** scripted.
///
/// Jedo's module branches on the scripted-fight flag `ctx[+0x287]`
/// (`beq v0,zero` at `0x801F8344`): a scripted fight takes the striking arm
/// (`FUN_801DD0AC(0x12, 7, seat)` per living monster, so the finisher's
/// slot-7 tail credits XP per hit as for every damaging summon); any other
/// fight takes the arm at `0x801F8558`, which strikes nothing and instead, for
/// each monster seat `3..=6` whose HP `+0x14C` is non-zero, bumps the caster's
/// magic-rank counter (record `+0x9C`, `0x801F8658`), sets the seat's `+0x21C`
/// to `0xC8`, and adds `3` to the cast spell's XP word (`0x801F86C0`) behind
/// the special-battle word.
///
/// REF: FUN_801F6A58 (PROT 0931 non-scripted arm)
pub const JEDO_XP_PER_LIVING_MONSTER: u32 = 3;

/// Menu-cast heal spell-XP grant - PORT: FUN_800402F4 (HP-heal arms).
///
/// Single-target arm (case body `0x80040470`): `+0xC` when the target's
/// HP deficit covered the spell's full level-scaled heal cap, `+0x4` when
/// the deficit was smaller (the heal was clipped). Multi-target arm (case
/// body `0x80040908`): `+0x3` / `+0x1` per healed party member (a
/// zero-deficit member accrues nothing, and the engine's cast flow refuses
/// those targets earlier).
pub fn menu_heal_xp_gain(group_cast: bool, full_power: bool) -> u32 {
    match (group_cast, full_power) {
        (false, true) => 12,
        (false, false) => 4,
        (true, true) => 3,
        (true, false) => 1,
    }
}

/// A spell level-up resolved by [`accrue_and_level`]: the spell-list slot
/// that leveled and the level byte now in the record.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SpellLevelUp {
    /// Index into the record's `+0x13D` spell-id list (retail's
    /// `_DAT_8007BB78` notification half).
    pub spell_slot: usize,
    /// The bumped `+0x161 + slot` level byte's new value.
    pub new_level: u8,
}

/// Shared accrue-then-level kernel - the one place the per-spell XP
/// accumulator meets the `0x8007656C` threshold table. Both retail casters
/// funnel here: the battle summon path (`World::accrue_summon_spell_xp`,
/// REF: FUN_801e70bc) and the pause-menu cast (REF: FUN_800402F4, whose
/// inline copy compares the raw table entry - byte-equal to the shared
/// compare for every spell id the menu arms credit, since none of the
/// [`legaia_engine_battle_vm::battle_formulas::SUMMON_XP_TRIPLE_THRESHOLD_IDS`]
/// is a menu-heal id).
///
/// Adds `gain` to the accumulator of `spell_id`'s slot, then (when a
/// threshold table is installed) bumps the `+0x161` level byte if the
/// accrued total strictly exceeds the level's threshold (`level < 9` cap).
/// Returns the level-up, `None` when nothing leveled. A spell the record
/// doesn't carry accrues nothing (retail would walk past the arrays; the
/// engine skips).
pub fn accrue_and_level(
    record: &mut CharacterRecord,
    spell_id: u8,
    gain: u32,
    thresholds: Option<&[u16]>,
) -> Option<SpellLevelUp> {
    let slot = spell_slot(record, spell_id)?;
    add_spell_xp(record, slot, gain);
    let table = thresholds?;
    let mut list = record.spell_list();
    let level = list.levels[slot];
    let xp = spell_xp(record, slot);
    if !legaia_engine_battle_vm::battle_formulas::summon_magic_levels_up(spell_id, level, xp, table)
    {
        return None;
    }
    list.levels[slot] = level + 1;
    record.set_spell_list(list);
    Some(SpellLevelUp {
        spell_slot: slot,
        new_level: level + 1,
    })
}

/// The **window 7** notification beat: retail's `FUN_80035C00(slot, index)`
/// pair (`_DAT_8007BB70` / `_DAT_8007BB78`) plus what the engine's painter
/// call needs pre-resolved. Held by `crate::menu_runtime::MenuRuntime`
/// until a confirm / cancel press, painted by both hosts through
/// `engine-ui`'s `char_prompt_draws_for` (window id 7, `FUN_801DCCB4`).
///
/// REF: FUN_80035C00
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SpellLevelNotice {
    /// Roster slot of the caster (retail `_DAT_8007BB70`).
    pub caster_slot: u8,
    /// Index into the caster's spell-id list (retail `_DAT_8007BB78`).
    pub spell_index: u8,
    /// The spell id at that index - the byte retail's window 7 substitutes
    /// into its prompt line (`record[0x13D + index]`).
    pub spell_id: u8,
    /// The leveled byte's new value.
    pub new_level: u8,
    /// The prompt line the hosts draw, as font bytes. Retail patches the
    /// spell id into the operand of the `0xC3` (spell-name) token that opens
    /// the menu overlay's sentence at `0x801E46E4` and draws it through the
    /// string primitive; the host builds the same bytes off the user's disc
    /// (the sentence, then the raw spell name with its `0xCE` element plate).
    /// Without the overlay it falls back to the battle-banner sentence
    /// ([`magic_level_increased_message`]) around the spell's name.
    pub line: Vec<u8>,
}

/// The banner suffix retail appends after the spell name (battle-action
/// overlay rodata at `0x801F6840 + 4` - the `+4` skips a 4-byte glyph-prefix
/// chain, leaving the possessive suffix).
pub const MAGIC_LEVEL_INCREASED_SUFFIX: &str = "'s magic level increased.";

/// Compose the "magic level increased" banner shown when a Seru spell levels
/// up: the cast spell's name (`DAT_800754D0[actor[+0x1DF]]`, the shared
/// spell-name table) followed by [`MAGIC_LEVEL_INCREASED_SUFFIX`]. Retail
/// builds it into the shared context message buffer `_DAT_8007BD24 + 0x1F9`
/// (string copy `FUN_8003CA78` + append `FUN_8003CAC4`).
///
/// PORT: FUN_801F452C
///
/// Driven from `World::accrue_summon_spell_xp`: the same edge that pushes
/// `World::seru.magic_level_ups` composes this line and stages it on the world's
/// banner channel, resolving the spell name through `World::tables.spell_catalog`.
/// Retail raises it as its own UI element (`0x65`); the engine has one
/// banner slot, so the two share it.
pub fn magic_level_increased_message(spell_name: &str) -> String {
    format!("{spell_name}{MAGIC_LEVEL_INCREASED_SUFFIX}")
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Each heal module's two grants, keyed on whether the missing HP covers
    /// its level-scaled amount (Vera lv 1 = 0x100, Orb lv 1 = 0x200, Spoon
    /// lv 1 = 0x400).
    #[test]
    fn module_heal_xp_grants_per_module() {
        // (id, hp, max) -> grant
        for (id, hp, max, want) in [
            (0x83u8, 0u16, 0x100u16, 0xCu32),
            (0x83, 1, 0x100, 0x4),
            (0x89, 0, 0x200, 0x4),
            (0x89, 1, 0x200, 0x2),
            (0x91, 0, 0x400, 0x4),
            (0x91, 1, 0x400, 0x2),
            (0x91, 0x400, 0x400, 0),
            (0x81, 0, 0x400, 0),
        ] {
            assert_eq!(
                module_heal_xp_gain(id, 1, hp, max),
                want,
                "id {id:#x} hp {hp}"
            );
        }
    }

    /// Horn's per-seat grant: `+3` for a seat missing HP, `+1` for a seat
    /// with a status word, both stacking; a full, clean seat earns nothing.
    #[test]
    fn horn_seat_xp_grants() {
        assert_eq!(horn_seat_xp_gain(10, 10, false), 0);
        assert_eq!(horn_seat_xp_gain(9, 10, false), 3);
        assert_eq!(horn_seat_xp_gain(10, 10, true), 1);
        assert_eq!(horn_seat_xp_gain(0, 10, true), 4);
    }

    /// Minimal synthetic PS-X EXE: header + zeroed text with a threshold
    /// table planted at the retail VA. No Sony bytes.
    fn synthetic_scus(table: &[u16]) -> Vec<u8> {
        let t_addr: u32 = 0x8001_0000;
        let t_size: u32 = 0x7_0000;
        let mut scus = vec![0u8; 0x800 + t_size as usize];
        scus[0..8].copy_from_slice(b"PS-X EXE");
        scus[0x18..0x1C].copy_from_slice(&t_addr.to_le_bytes());
        scus[0x1C..0x20].copy_from_slice(&t_size.to_le_bytes());
        let off = (THRESHOLDS_VA - t_addr) as usize + 0x800;
        for (i, v) in table.iter().enumerate() {
            scus[off + i * 2..off + i * 2 + 2].copy_from_slice(&v.to_le_bytes());
        }
        scus
    }

    #[test]
    fn thresholds_decode_from_synthetic_exe() {
        let table = [17u16, 50, 92, 144, 208, 288, 392, 536];
        let scus = synthetic_scus(&table);
        assert_eq!(thresholds_from_scus(&scus), Some(table));
    }

    #[test]
    fn thresholds_reject_non_ascending_or_zero() {
        // Zero first entry.
        let scus = synthetic_scus(&[0, 50, 92, 144, 208, 288, 392, 536]);
        assert_eq!(thresholds_from_scus(&scus), None);
        // Non-ascending.
        let scus = synthetic_scus(&[17, 50, 50, 144, 208, 288, 392, 536]);
        assert_eq!(thresholds_from_scus(&scus), None);
        // Not a PS-X EXE.
        assert_eq!(thresholds_from_scus(&[0u8; 0x1000]), None);
    }

    #[test]
    fn spell_xp_round_trips_through_record_raw() {
        let mut rec = CharacterRecord::zeroed();
        let mut list = rec.spell_list();
        list.count = 2;
        list.ids[0] = 0x81;
        list.ids[1] = 0x87;
        list.levels[0] = 1;
        list.levels[1] = 3;
        rec.set_spell_list(list);

        let slot = spell_slot(&rec, 0x87).expect("spell in list");
        assert_eq!(slot, 1);
        assert_eq!(spell_xp(&rec, slot), 0);
        add_spell_xp(&mut rec, slot, 12);
        add_spell_xp(&mut rec, slot, 5);
        assert_eq!(spell_xp(&rec, slot), 17);
        // The XP lands in the +0x8 u32 array (live 0x80084710 + slot*4).
        assert_eq!(rec.raw[SPELL_XP_OFFSET + 4], 17);
        // Unknown spell: no slot.
        assert_eq!(spell_slot(&rec, 0xA0), None);
    }

    #[test]
    fn spell_slot_respects_retail_search_bound() {
        let mut rec = CharacterRecord::zeroed();
        let mut list = rec.spell_list();
        // MAX_SPELLS (36) > the retail 0x20 bound: a spell parked in slot
        // 0x21 is invisible to the XP path, exactly like retail.
        list.count = 36;
        list.ids[0x21] = 0x8B;
        rec.set_spell_list(list);
        assert_eq!(spell_slot(&rec, 0x8B), None);
    }

    #[test]
    fn learn_prepend_shifts_ids_levels_and_xp() {
        let mut rec = CharacterRecord::zeroed();
        let mut list = rec.spell_list();
        list.count = 2;
        list.ids[0] = 0x83; // level 4
        list.ids[1] = 0x81; // level 2
        list.levels[0] = 4;
        list.levels[1] = 2;
        rec.set_spell_list(list);
        add_spell_xp(&mut rec, 0, 77);
        add_spell_xp(&mut rec, 1, 33);

        learn_spell_prepend(&mut rec, 0x8B);
        let l = rec.spell_list();
        assert_eq!(l.count, 3);
        // The array holds the FULL id (retail stores `arg + 0x80`), which is
        // the same id space `spell_slot` scans by.
        assert_eq!(&l.ids[..3], &[0x8B, 0x83, 0x81]);
        assert_eq!(spell_slot(&rec, 0x8B), Some(0));
        assert_eq!(&l.levels[..3], &[1, 4, 2]);
        assert_eq!(spell_xp(&rec, 0), 0, "new spell starts at zero XP");
        assert_eq!(spell_xp(&rec, 1), 77, "old slot-0 XP moved with it");
        assert_eq!(spell_xp(&rec, 2), 33);
    }

    #[test]
    fn menu_heal_xp_gain_matches_the_retail_grants() {
        // FUN_800402F4: single-target heal arm +0xC / +0x4, multi-target
        // loop +0x3 / +0x1.
        assert_eq!(menu_heal_xp_gain(false, true), 12);
        assert_eq!(menu_heal_xp_gain(false, false), 4);
        assert_eq!(menu_heal_xp_gain(true, true), 3);
        assert_eq!(menu_heal_xp_gain(true, false), 1);
    }

    fn record_with_spell(spell_id: u8, level: u8) -> CharacterRecord {
        let mut rec = CharacterRecord::zeroed();
        let mut list = rec.spell_list();
        list.count = 1;
        list.ids[0] = spell_id;
        list.levels[0] = level;
        rec.set_spell_list(list);
        rec
    }

    #[test]
    fn accrue_and_level_bumps_on_strict_threshold_cross() {
        let table = [17u16, 50, 92, 144, 208, 288, 392, 536];
        let mut rec = record_with_spell(0x83, 1);
        // 12 XP: below the 17 threshold - accrued, no level.
        assert_eq!(accrue_and_level(&mut rec, 0x83, 12, Some(&table)), None);
        assert_eq!(spell_xp(&rec, 0), 12);
        // +12 = 24 > 17: level 1 -> 2, XP keeps accumulating (no reset).
        assert_eq!(
            accrue_and_level(&mut rec, 0x83, 12, Some(&table)),
            Some(SpellLevelUp {
                spell_slot: 0,
                new_level: 2
            })
        );
        assert_eq!(rec.spell_list().levels[0], 2);
        assert_eq!(spell_xp(&rec, 0), 24);
    }

    #[test]
    fn accrue_and_level_without_thresholds_accrues_only() {
        let mut rec = record_with_spell(0x83, 1);
        assert_eq!(accrue_and_level(&mut rec, 0x83, 500, None), None);
        assert_eq!(spell_xp(&rec, 0), 500);
        assert_eq!(rec.spell_list().levels[0], 1, "no table, no level change");
    }

    #[test]
    fn accrue_and_level_skips_a_spell_the_record_lacks() {
        let table = [17u16, 50, 92, 144, 208, 288, 392, 536];
        let mut rec = record_with_spell(0x83, 1);
        assert_eq!(accrue_and_level(&mut rec, 0x89, 100, Some(&table)), None);
        assert_eq!(spell_xp(&rec, 0), 0, "nothing accrued to the wrong slot");
    }

    #[test]
    fn accrue_and_level_caps_at_level_nine() {
        let table = [17u16, 50, 92, 144, 208, 288, 392, 536];
        let mut rec = record_with_spell(0x83, 9);
        assert_eq!(accrue_and_level(&mut rec, 0x83, 10_000, Some(&table)), None);
        assert_eq!(rec.spell_list().levels[0], 9);
    }

    #[test]
    fn level_up_banner_appends_the_retail_suffix() {
        assert_eq!(
            magic_level_increased_message("Gimard"),
            "Gimard's magic level increased."
        );
    }
}
