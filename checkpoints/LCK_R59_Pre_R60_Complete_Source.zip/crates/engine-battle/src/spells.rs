//! Spell catalog and pure-functional cast resolver.
//!
//! Tactical Arts are character-driven attack chains; spells are the
//! magic-side of the same command menu (ActionConstant `Magic = 0x02`,
//! followed by a per-character spell list). This module mirrors the shape
//! of `legaia_engine_menus::items`: a typed catalog keyed by spell id, plus a pure
//! [`cast_spell`] function that consumes a [`SpellSnapshot`] and returns
//! a [`SpellOutcome`].
//!
//! The retail engine threads spell casts through:
//!   - `BattleActionHost::spell_mp_cost(id)` - MP gate (already exposed).
//!   - `BattleActionHost::is_capture_spell(id)` - Capture branch flag.
//!   - `BattleActionHost::spell_anim_trigger(party_slot, spell_id)` -
//!     fires `BattleEvent::SpellAnimTrigger`.
//!   - `BattleActionHost::apply_damage(...)` - for offensive spells.
//!
//! Engines that already drive their own per-spell anim list don't need
//! this catalog; it's a *minimum-viable* spell system that can be wired
//! end-to-end without an overlay capture for the per-spell base power
//! tables. Engines populate the catalog from disc data when the
//! per-character spell list is known.

use legaia_engine_battle_vm::status_effects::StatusKind;
use std::collections::HashMap;

/// Magic element. Matches the eight retail elemental columns plus a
/// neutral catch-all for spells that aren't explicitly elemental.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum SpellElement {
    #[default]
    Neutral,
    Fire,
    Water,
    Wind,
    Thunder,
    Ice,
    Earth,
    Light,
    Dark,
}

impl SpellElement {
    /// Per-element type-effectiveness multiplier against a target with the
    /// listed weakness flags. The retail engine maps each element to a
    /// 4-bit mask; matching elements amplify damage by 1.5x. Engines that
    /// don't model weaknesses pass [`ElementMask::empty`] for a 1.0x
    /// passthrough.
    pub fn multiplier_against(self, weak: ElementMask) -> f32 {
        if weak.contains(self) { 1.5 } else { 1.0 }
    }
}

/// Bitmask of element weaknesses on a target. Engines populate from the
/// monster record's elemental flags.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct ElementMask(pub u16);

impl ElementMask {
    pub const fn empty() -> Self {
        Self(0)
    }

    pub fn contains(self, element: SpellElement) -> bool {
        let bit = match element {
            SpellElement::Neutral => return false,
            SpellElement::Fire => 1 << 0,
            SpellElement::Water => 1 << 1,
            SpellElement::Wind => 1 << 2,
            SpellElement::Thunder => 1 << 3,
            SpellElement::Ice => 1 << 4,
            SpellElement::Earth => 1 << 5,
            SpellElement::Light => 1 << 6,
            SpellElement::Dark => 1 << 7,
        };
        (self.0 & bit) != 0
    }

    pub fn with(mut self, element: SpellElement) -> Self {
        let bit = match element {
            SpellElement::Neutral => 0,
            SpellElement::Fire => 1 << 0,
            SpellElement::Water => 1 << 1,
            SpellElement::Wind => 1 << 2,
            SpellElement::Thunder => 1 << 3,
            SpellElement::Ice => 1 << 4,
            SpellElement::Earth => 1 << 5,
            SpellElement::Light => 1 << 6,
            SpellElement::Dark => 1 << 7,
        };
        self.0 |= bit;
        self
    }
}

/// What slot the spell hits.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum SpellTarget {
    /// Single ally (party-side, including caster).
    OneAlly,
    /// Every ally.
    AllAllies,
    /// Single enemy. **Default** because most spells in retail have this
    /// shape - engines can override per spell.
    #[default]
    OneEnemy,
    /// Every enemy.
    AllEnemies,
    /// Caster targets themselves (most buff spells).
    SelfOnly,
}

impl SpellTarget {
    /// The two target bits of retail's spell-table `+2` stats byte for this
    /// shape: `0x02` = ally side, `0x20` = all targets. The inverse of
    /// `legaia_game_tables::spell_names::SpellStats::target_shape`, which is how
    /// [`crate::retail_magic`] fills the shape in the first place.
    ///
    /// It exists so the screens that branch on that byte can run retail's own
    /// predicate over it rather than re-deciding on the typed shape. The
    /// menu's `FUN_801D9110` confirm dispatch is one
    /// (`legaia_engine_menus::spell_menu::spell_targets_group`); the byte's other bits
    /// (element / usability) belong to different readers and are not
    /// reconstructed here.
    ///
    /// `SelfOnly` has no retail encoding of its own - it is the engine's
    /// label for a single-ally spell whose only sensible row is the caster -
    /// so it carries the single-ally bits.
    pub const fn retail_target_flag_bits(self) -> u8 {
        match self {
            SpellTarget::OneEnemy => 0,
            SpellTarget::AllEnemies => legaia_game_tables::spell_names::TARGET_ALL_BIT,
            SpellTarget::OneAlly | SpellTarget::SelfOnly => {
                legaia_game_tables::spell_names::TARGET_ALLY_BIT
            }
            SpellTarget::AllAllies => {
                legaia_game_tables::spell_names::TARGET_ALLY_BIT
                    | legaia_game_tables::spell_names::TARGET_ALL_BIT
            }
        }
    }
}

/// Buffable / debuffable stat. The retail engine modifies a small set of
/// per-actor scalars during a magic phase; this enum mirrors them.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum BuffStat {
    Attack,
    Defense,
    Accuracy,
    Evasion,
    /// Speed / initiative - folds into turn-order recompute.
    Speed,
    /// Magic attack scalar.
    MagicAttack,
    /// Magic defense scalar.
    MagicDefense,
}

/// Concrete effect a spell produces when cast.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SpellEffect {
    /// Damage with elemental multiplier. Final damage is
    /// `(caster_mag * mult / 8) - target_mdef` clamped at 1.
    Damage {
        base_power: u16,
        element: SpellElement,
    },
    /// Heal a fixed HP amount (Heal-class spells in retail are scalar,
    /// not formula-driven).
    Heal { amount: u16 },
    /// Heal every party member by `amount`.
    HealAll { amount: u16 },
    /// Cure one named status.
    Cure(StatusKind),
    /// Cure every status on the target.
    CureAll,
    /// Revive with the listed HP percentage.
    Revive { hp_pct: u8 },
    /// Apply a stat buff for `turns` turns. Magnitude can be negative for
    /// debuffs.
    Buff {
        stat: BuffStat,
        magnitude: i16,
        turns: u8,
    },
    /// Capture spell. Engines roll capture independently; the resolver
    /// surfaces the spell's hit chance.
    Capture { hit_pct: u8 },
    /// Field-only escape spell. Always succeeds in non-boss battles.
    Escape,
}

impl Default for SpellEffect {
    fn default() -> Self {
        Self::Damage {
            base_power: 0,
            element: SpellElement::Neutral,
        }
    }
}

/// One spell definition. Engines populate the catalog at battle init from
/// disc data + the per-character learned-spell list.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SpellDef {
    pub id: u8,
    /// Display name. Default "Spell {id}" for unknown spells.
    pub name: String,
    pub mp_cost: u8,
    pub element: SpellElement,
    pub target: SpellTarget,
    pub effect: SpellEffect,
    /// Animation id wired to `BattleActionHost::spell_anim_trigger`.
    /// `0` = no animation.
    pub anim_id: u8,
    /// Spell-table `+0x01` **effect class** - the key `FUN_801F2160` bounds
    /// with `sltiu ..., 0x20` and dispatches a capture-class cast's module on
    /// (PROT `935 + class`, see
    /// `legaia_overlay_images::cast_effect_pool::capture_module_prot`). `0` on the
    /// placeholder catalog and on any record built without the disc table;
    /// [`crate::retail_magic`] fills it from `SCUS_942.54`.
    pub effect_class: u8,
}

impl Default for SpellDef {
    fn default() -> Self {
        Self {
            id: 0,
            name: "(unknown)".into(),
            mp_cost: 0,
            element: SpellElement::Neutral,
            target: SpellTarget::OneEnemy,
            effect: SpellEffect::default(),
            anim_id: 0,
            effect_class: 0,
        }
    }
}

/// Spell catalog. Engines populate at battle init; the
/// `BattleActionHost::spell_mp_cost` lookup falls back here if engines
/// install the catalog into the world.
#[derive(Debug, Clone, Default)]
pub struct SpellCatalog {
    spells: HashMap<u8, SpellDef>,
}

impl SpellCatalog {
    pub fn new() -> Self {
        Self {
            spells: HashMap::new(),
        }
    }

    /// Pre-populate with a small "vanilla" catalog covering the canonical
    /// retail spell list. Useful for tests and the `legaia-engine battle`
    /// subcommand. The base powers are placeholders pending overlay
    /// capture of the real values.
    pub fn vanilla() -> Self {
        let mut c = Self::new();
        // Healing spells.
        c.insert(SpellDef {
            id: 0x10,
            name: "Heal".into(),
            mp_cost: 4,
            target: SpellTarget::OneAlly,
            effect: SpellEffect::Heal { amount: 60 },
            anim_id: 0x20,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x11,
            name: "Heal All".into(),
            mp_cost: 8,
            target: SpellTarget::AllAllies,
            effect: SpellEffect::HealAll { amount: 60 },
            anim_id: 0x21,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x12,
            name: "Mega Heal".into(),
            mp_cost: 12,
            target: SpellTarget::OneAlly,
            effect: SpellEffect::Heal { amount: 200 },
            anim_id: 0x22,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x13,
            name: "Refresh".into(),
            mp_cost: 6,
            target: SpellTarget::OneAlly,
            effect: SpellEffect::CureAll,
            anim_id: 0x23,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x14,
            name: "Vital".into(),
            mp_cost: 16,
            target: SpellTarget::OneAlly,
            effect: SpellEffect::Revive { hp_pct: 50 },
            anim_id: 0x24,
            ..Default::default()
        });
        // Offensive elemental spells.
        c.insert(SpellDef {
            id: 0x20,
            name: "Flame".into(),
            mp_cost: 5,
            element: SpellElement::Fire,
            target: SpellTarget::OneEnemy,
            effect: SpellEffect::Damage {
                base_power: 80,
                element: SpellElement::Fire,
            },
            anim_id: 0x40,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x21,
            name: "Burning Heat".into(),
            mp_cost: 10,
            element: SpellElement::Fire,
            target: SpellTarget::AllEnemies,
            effect: SpellEffect::Damage {
                base_power: 60,
                element: SpellElement::Fire,
            },
            anim_id: 0x41,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x22,
            name: "Aqua".into(),
            mp_cost: 5,
            element: SpellElement::Water,
            target: SpellTarget::OneEnemy,
            effect: SpellEffect::Damage {
                base_power: 80,
                element: SpellElement::Water,
            },
            anim_id: 0x42,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x23,
            name: "Thunder Bolt".into(),
            mp_cost: 8,
            element: SpellElement::Thunder,
            target: SpellTarget::OneEnemy,
            effect: SpellEffect::Damage {
                base_power: 100,
                element: SpellElement::Thunder,
            },
            anim_id: 0x43,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x24,
            name: "Wind".into(),
            mp_cost: 6,
            element: SpellElement::Wind,
            target: SpellTarget::OneEnemy,
            effect: SpellEffect::Damage {
                base_power: 90,
                element: SpellElement::Wind,
            },
            anim_id: 0x44,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x25,
            name: "Ice".into(),
            mp_cost: 7,
            element: SpellElement::Ice,
            target: SpellTarget::OneEnemy,
            effect: SpellEffect::Damage {
                base_power: 95,
                element: SpellElement::Ice,
            },
            anim_id: 0x45,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x26,
            name: "Crash".into(),
            mp_cost: 9,
            element: SpellElement::Earth,
            target: SpellTarget::OneEnemy,
            effect: SpellEffect::Damage {
                base_power: 110,
                element: SpellElement::Earth,
            },
            anim_id: 0x46,
            ..Default::default()
        });
        // Buff / debuff spells.
        c.insert(SpellDef {
            id: 0x30,
            name: "Power Up".into(),
            mp_cost: 5,
            target: SpellTarget::OneAlly,
            effect: SpellEffect::Buff {
                stat: BuffStat::Attack,
                magnitude: 20,
                turns: 4,
            },
            anim_id: 0x50,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x31,
            name: "Defense Up".into(),
            mp_cost: 5,
            target: SpellTarget::OneAlly,
            effect: SpellEffect::Buff {
                stat: BuffStat::Defense,
                magnitude: 20,
                turns: 4,
            },
            anim_id: 0x51,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x32,
            name: "Speed Up".into(),
            mp_cost: 6,
            target: SpellTarget::OneAlly,
            effect: SpellEffect::Buff {
                stat: BuffStat::Speed,
                magnitude: 15,
                turns: 4,
            },
            anim_id: 0x52,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x33,
            name: "Power Down".into(),
            mp_cost: 5,
            target: SpellTarget::OneEnemy,
            effect: SpellEffect::Buff {
                stat: BuffStat::Attack,
                magnitude: -20,
                turns: 4,
            },
            anim_id: 0x53,
            ..Default::default()
        });
        // Capture / escape.
        c.insert(SpellDef {
            id: 0x40,
            name: "Reseal".into(),
            mp_cost: 12,
            target: SpellTarget::OneEnemy,
            effect: SpellEffect::Capture { hit_pct: 60 },
            anim_id: 0x60,
            ..Default::default()
        });
        c.insert(SpellDef {
            id: 0x41,
            name: "Warp".into(),
            mp_cost: 8,
            target: SpellTarget::SelfOnly,
            effect: SpellEffect::Escape,
            anim_id: 0x61,
            ..Default::default()
        });
        // Port-side monster-spell block. The per-monster-id AI script
        // ([`crate::monster_ai`]) emits retail monster spell ids; the real
        // shapes/powers come from the disc spell table. These placeholders cover
        // the ids the early-roster cases use so their scripted casts fold and
        // draw disc-free (effects/powers are stand-ins, like the player block).
        for &(id, name, mp, target, dmg) in &[
            (0x50u8, "Monster Buff", 6u8, SpellTarget::SelfOnly, 0u16),
            (0x51, "Monster Bolt", 5, SpellTarget::OneEnemy, 70),
            (0x52, "Monster Mend", 8, SpellTarget::SelfOnly, 0),
            (0x53, "Monster Burst", 12, SpellTarget::AllEnemies, 60),
            (0x60, "Monster Guard", 10, SpellTarget::SelfOnly, 0),
            (0x6f, "Monster Spit", 9, SpellTarget::OneEnemy, 80),
            // Boss-phase block - the spells the multi-phase scripted cases pick
            // by battle-mode (`ctx+0x28A`); see [`crate::monster_ai`] id `0xB6`.
            (0xa1, "Boss Nova", 30, SpellTarget::AllEnemies, 120),
            (0xa2, "Boss Phase I", 20, SpellTarget::SelfOnly, 0),
            (0xa3, "Boss Phase II", 24, SpellTarget::SelfOnly, 0),
            (0xa4, "Boss Phase III", 28, SpellTarget::SelfOnly, 0),
            (0xa5, "Boss Smite", 26, SpellTarget::OneEnemy, 100),
        ] {
            let effect = if dmg > 0 {
                SpellEffect::Damage {
                    base_power: dmg,
                    element: SpellElement::Neutral,
                }
            } else if target == SpellTarget::SelfOnly && name.contains("Mend") {
                SpellEffect::Heal { amount: 80 }
            } else {
                SpellEffect::Buff {
                    stat: BuffStat::Defense,
                    magnitude: 15,
                    turns: 4,
                }
            };
            c.insert(SpellDef {
                id,
                name: name.into(),
                mp_cost: mp,
                target,
                effect,
                ..Default::default()
            });
        }
        c
    }

    pub fn insert(&mut self, def: SpellDef) {
        self.spells.insert(def.id, def);
    }

    pub fn get(&self, id: u8) -> Option<&SpellDef> {
        self.spells.get(&id)
    }

    pub fn len(&self) -> usize {
        self.spells.len()
    }

    pub fn is_empty(&self) -> bool {
        self.spells.is_empty()
    }

    /// Iterate all defined spells in arbitrary order.
    pub fn iter(&self) -> impl Iterator<Item = &SpellDef> {
        self.spells.values()
    }

    /// Aggregate MP-cost lookup. Mirrors the
    /// `BattleActionHost::spell_mp_cost` callback so engines can install
    /// the catalog as the canonical source.
    pub fn mp_cost(&self, id: u8) -> u8 {
        self.spells.get(&id).map(|s| s.mp_cost).unwrap_or(0)
    }

    /// `true` when the spell is the Capture / Reseal class. Mirrors
    /// `BattleActionHost::is_capture_spell`.
    pub fn is_capture(&self, id: u8) -> bool {
        matches!(
            self.spells.get(&id).map(|s| &s.effect),
            Some(SpellEffect::Capture { .. })
        )
    }
}

/// Per-cast snapshot. Engines pull these scalars from the live actor
/// table at the moment the cast resolves.
#[derive(Debug, Clone, Default)]
pub struct SpellSnapshot {
    /// Caster's Magic stat (the retail aggregator's `mag` column).
    pub caster_mag: u16,
    pub caster_hp: u16,
    pub caster_max_hp: u16,
    pub caster_mp: u16,
    /// Caster's active-abilities word (record `+0xF4`). The MP gate reads
    /// the cost through [`caster_mp_cost`], so an MP-saver accessory lowers
    /// the threshold exactly as it lowers the debit. `0` = no discount.
    pub caster_ability_bits: u32,
    /// Target's Magic Defense scalar.
    pub target_mdef: u16,
    pub target_hp: u16,
    pub target_hp_max: u16,
    pub target_mp: u16,
    pub target_alive: bool,
    /// Element-weakness mask for the target (empty for non-elemental).
    pub target_weakness: ElementMask,
}

/// Why a cast failed when no in-game effect resolved.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SpellFailReason {
    /// MP gauge was below `mp_cost`.
    NotEnoughMp,
    /// Cast a single-target offensive spell on a dead actor.
    DeadTarget,
    /// Cast a healing or revive spell on a target whose state didn't
    /// change (revive on alive, heal on already-full HP).
    NoChange,
    /// Tried to cast a single-target ally spell on a non-ally slot.
    InvalidTarget,
    /// Catalog had no entry for this id.
    UnknownSpell,
}

/// Effect a successful cast applied. Engines fold these into world state
/// (HP / MP / status / buff timers).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SpellOutcome {
    /// Damage spell. `amount` is the post-formula damage; `mult` is the
    /// elemental multiplier engines can show in the HUD.
    Damage {
        target: u8,
        amount: u16,
        element: SpellElement,
        weakness: bool,
    },
    /// Multi-target damage. Per-target entries.
    MultiDamage {
        targets: Vec<(u8, u16)>,
        element: SpellElement,
    },
    /// Heal - single target.
    Heal { target: u8, amount: u16 },
    /// Heal - multi target.
    MultiHeal { targets: Vec<(u8, u16)> },
    /// Cure - `removed` is the count of statuses cleared.
    Cure { target: u8, removed: u8 },
    /// Revive with the resolved HP value.
    Revive { target: u8, hp: u16 },
    /// Buff applied. `magnitude` may be negative.
    Buff {
        target: u8,
        stat: BuffStat,
        magnitude: i16,
        turns: u8,
    },
    /// Capture-spell hit. Engines roll the actual capture vs. monster HP.
    CaptureRoll { target: u8, hit_pct: u8 },
    /// Escape spell - caster fled the encounter.
    Escape,
    /// Cast was rolled but produced no effect.
    Failed { reason: SpellFailReason },
}

/// The MP a caster whose record `+0xF4` word is `ability_bits` pays for
/// `spell` - the spell record's `+3` byte folded through the MP-saver bits
/// (`0x20` = half off, `0x10` = a quarter off, half winning).
///
/// Retail runs every cast's price through the one SCUS kernel
/// `FUN_80035394(caster, cost)` or an inline copy of it, and the compare and
/// the debit read the same number: the Magic list build inlines it at
/// `0x8003118C..0x800311A4` and greys a row on `record+0x10A < cost`
/// (`0x80031204`); the single-target cast debits its return at
/// `0x801D93C0..0x801D9418` and the group cast at `0x801D972C` (both in
/// PROT 0899, the menu overlay); the re-cast gates compare against it at
/// `0x801D953C` / `0x801D98A4`; the list and status panels draw it
/// (`0x801D3064`, `0x801D4344`); battle inlines it in `FUN_801E295C`.
/// Every engine cast path routes through this function so none of them can
/// compare one price and charge another.
///
/// REF: FUN_80035394 (the fold is [`legaia_engine_battle_vm::battle_formulas::mp_cost_after_ability_bits`])
pub fn caster_mp_cost(spell: &SpellDef, ability_bits: u32) -> u16 {
    use legaia_engine_battle_vm::battle_formulas::{MpCostModifier, mp_cost_after_ability_bits};
    mp_cost_after_ability_bits(
        spell.mp_cost as u16,
        MpCostModifier::from_ability_flags(ability_bits),
    )
}

/// Record `+0xF4` word 0 of a character record - the word
/// [`caster_mp_cost`]'s bits live in (retail `lw 0x6bc(v)` off the
/// `0x80084140` window at `0x800353B4` / `0x80031174`).
pub fn record_ability_word(rec: &legaia_save::CharacterRecord) -> u32 {
    let b = rec.ability_bits();
    u32::from_le_bytes([b[0], b[1], b[2], b[3]])
}

/// Resolve a spell cast.
///
/// Pure function. Engines pass per-target snapshots because the catalog
/// itself doesn't carry actor pointers; multi-target spells require a
/// matching shape (`AllAllies` -> 3 snapshots, `AllEnemies` -> N enemy
/// snapshots).
pub fn cast_spell(spell: &SpellDef, target_slot: u8, snap: &SpellSnapshot) -> SpellOutcome {
    if snap.caster_mp < caster_mp_cost(spell, snap.caster_ability_bits) {
        return SpellOutcome::Failed {
            reason: SpellFailReason::NotEnoughMp,
        };
    }
    match &spell.effect {
        SpellEffect::Damage {
            base_power,
            element,
        } => {
            if !snap.target_alive {
                return SpellOutcome::Failed {
                    reason: SpellFailReason::DeadTarget,
                };
            }
            let mult = element.multiplier_against(snap.target_weakness);
            let raw = (snap.caster_mag as u32 * (*base_power as u32) / 8)
                .saturating_sub(snap.target_mdef as u32);
            let scaled = ((raw as f32) * mult).round() as u32;
            let dmg = scaled.max(1).min(u16::MAX as u32) as u16;
            SpellOutcome::Damage {
                target: target_slot,
                amount: dmg,
                element: *element,
                weakness: snap.target_weakness.contains(*element),
            }
        }
        SpellEffect::Heal { amount } => {
            if !snap.target_alive {
                return SpellOutcome::Failed {
                    reason: SpellFailReason::DeadTarget,
                };
            }
            let cap = snap.target_hp_max.saturating_sub(snap.target_hp);
            if cap == 0 {
                return SpellOutcome::Failed {
                    reason: SpellFailReason::NoChange,
                };
            }
            let actual = (*amount).min(cap);
            SpellOutcome::Heal {
                target: target_slot,
                amount: actual,
            }
        }
        SpellEffect::HealAll { amount } => {
            // Caller resolves multi-heal by calling `cast_spell` with each
            // ally snapshot - surfacing the heal amount the formula uses.
            if !snap.target_alive {
                return SpellOutcome::Failed {
                    reason: SpellFailReason::DeadTarget,
                };
            }
            let cap = snap.target_hp_max.saturating_sub(snap.target_hp);
            let actual = (*amount).min(cap);
            SpellOutcome::Heal {
                target: target_slot,
                amount: actual,
            }
        }
        SpellEffect::Cure(_) | SpellEffect::CureAll => SpellOutcome::Cure {
            target: target_slot,
            // Engines query the StatusEffectTracker for the actual count;
            // the resolver returns a zero placeholder.
            removed: 0,
        },
        SpellEffect::Revive { hp_pct } => {
            if snap.target_alive {
                return SpellOutcome::Failed {
                    reason: SpellFailReason::NoChange,
                };
            }
            let hp = (snap.target_hp_max as u32 * (*hp_pct as u32) / 100)
                .max(1)
                .min(snap.target_hp_max as u32) as u16;
            SpellOutcome::Revive {
                target: target_slot,
                hp,
            }
        }
        SpellEffect::Buff {
            stat,
            magnitude,
            turns,
        } => SpellOutcome::Buff {
            target: target_slot,
            stat: *stat,
            magnitude: *magnitude,
            turns: *turns,
        },
        SpellEffect::Capture { hit_pct } => {
            if !snap.target_alive {
                return SpellOutcome::Failed {
                    reason: SpellFailReason::DeadTarget,
                };
            }
            SpellOutcome::CaptureRoll {
                target: target_slot,
                hit_pct: *hit_pct,
            }
        }
        SpellEffect::Escape => SpellOutcome::Escape,
    }
}

#[cfg(test)]
mod tests;
